# Digital Mitraa - Multi-Service Consultancy Platform

A comprehensive digital marketing and multi-service consultancy platform powered by AI for Digital Mitraa.

![Digital Mitraa Logo](attached_assets/logo_transparent.png)

## Overview

Digital Mitraa is a comprehensive platform that provides consultancy services across multiple domains:

- Legal Services
- Digital Marketing
- Loan Services
- Insurance Services
- Real Estate Services

The platform supports multiple user roles including Admin, Franchisee, Bank Partner, and regular users, each with specific permissions and features.

## Key Features

### User Management
- Multi-role authentication (Admin, Franchisee, Bank Partner, User)
- Role-based access controls
- User approval workflow

### Service Management
- Service categories and listings
- Pricing and package management
- Service booking and tracking

### AI-Powered Marketing Assistant
- AI-generated marketing content
- SEO analysis and recommendations
- Business document generation
- Chat interface with persistent message storage

### Project Management
- Client project tracking
- Progress updates
- Document management

### Financial Management
- Invoice generation
- Wallet system
- Commission tracking for bank partners
- Payment processing

### Content Management
- Blog system with categories
- Marketing content repository
- Media management

## Technology Stack

- **Frontend**: React.js with Tailwind CSS and Shadcn UI components
- **Backend**: Node.js with Express.js
- **Database**: PostgreSQL with Drizzle ORM
- **AI Integration**: OpenAI GPT models
- **Authentication**: Session-based authentication with Passport.js
- **State Management**: React Query for server state
- **TypeScript**: For type-safe development
- **Responsive Design**: Mobile-first approach

## Getting Started

Please refer to the [Deployment Guide](DEPLOYMENT_GUIDE.md) for detailed setup and deployment instructions.

## Project Structure

```
├── client/              # Frontend React application
│   ├── src/             # Source code
│   │   ├── components/  # UI components
│   │   ├── hooks/       # Custom React hooks
│   │   ├── lib/         # Utility functions
│   │   ├── pages/       # Page components
│   │   └── assets/      # Static assets
├── server/              # Backend Express API
│   ├── auth.ts          # Authentication logic
│   ├── routes.ts        # API routes
│   ├── storage.ts       # Database access layer
│   └── openai.ts        # AI integration
├── shared/              # Shared code between frontend and backend
│   └── schema.ts        # Database schema and types
└── public/              # Static public files
```

## License

Proprietary - All Rights Reserved

## Contact

For inquiries, please contact Digital Mitraa support.