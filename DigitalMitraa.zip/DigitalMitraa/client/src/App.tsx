import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { ProtectedRoute } from "./lib/protected-route";

// Pages
import HomePage from "@/pages/home-page";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import ServicesPage from "@/pages/services-page";
import PricingPage from "@/pages/pricing-page";
import BlogPage from "@/pages/blog-page";
import ContactPage from "@/pages/contact-page";
import UserManagementPage from "@/pages/user-management-page";
import AiAssistantPage from "@/pages/ai-assistant-page";
import ProjectsPage from "@/pages/projects-page";
import AnalyticsPage from "@/pages/analytics-page";
import InvoicingPage from "@/pages/invoicing-page";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/services" component={ServicesPage} />
      <Route path="/pricing" component={PricingPage} />
      <Route path="/blog" component={BlogPage} />
      <Route path="/contact" component={ContactPage} />
      
      {/* Protected Dashboard Routes */}
      <ProtectedRoute path="/dashboard" component={DashboardPage} />
      <ProtectedRoute path="/dashboard/users" component={UserManagementPage} />
      <ProtectedRoute path="/dashboard/ai-assistant" component={AiAssistantPage} />
      <ProtectedRoute path="/dashboard/projects" component={ProjectsPage} />
      <ProtectedRoute path="/dashboard/analytics" component={AnalyticsPage} />
      <ProtectedRoute path="/dashboard/invoicing" component={InvoicingPage} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return <Router />;
}

export default App;
