import { createRoot } from "react-dom/client";
import { QueryClientProvider } from "@tanstack/react-query";
import App from "./App";
import "./index.css";
import { AuthProvider } from "./hooks/use-auth";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";

// Make sure all the providers are properly set up
const root = createRoot(document.getElementById("root")!);

// Intentionally async-wrapped to ensure all React context providers initialize before rendering
setTimeout(() => {
  root.render(
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <App />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}, 0);
