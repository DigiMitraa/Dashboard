import { useState, useRef, useEffect } from "react";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Message } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Bot, User, Send, Loader2, Info } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function AiAssistantPage() {
  const [message, setMessage] = useState("");
  const [tab, setTab] = useState("chat");
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: messages, isLoading } = useQuery<Message[]>({
    queryKey: ["/api/messages"],
    refetchInterval: false,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest("POST", "/api/messages", { content });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      setMessage("");
      // Focus input after sending
      if (inputRef.current) {
        inputRef.current.focus();
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send message",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const clearChatMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("DELETE", "/api/messages");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      toast({
        title: "Chat history cleared",
        description: "All messages have been deleted",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to clear chat",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      sendMessageMutation.mutate(message);
    }
  };

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollArea = scrollAreaRef.current;
      scrollArea.scrollTop = scrollArea.scrollHeight;
    }
  }, [messages]);

  const marketingPrompts = [
    "How can I improve my website's SEO?",
    "Create a content calendar for social media",
    "Generate email marketing campaign ideas",
    "Suggest keywords for my digital marketing agency",
    "Write a blog post outline about digital marketing trends",
    "How can I increase my conversion rate?",
    "Create a Facebook ad copy for my e-commerce store",
    "What are the best analytics tools for digital marketing?",
  ];

  return (
    <DashboardLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">AI Marketing Assistant</h1>
              <p className="mt-1 text-sm text-gray-500">
                Get AI-powered help with your digital marketing strategy, content creation, and more.
              </p>
            </div>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm" className="ml-4">
                  <Info className="mr-2 h-4 w-4" />
                  About
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>About the AI Assistant</AlertDialogTitle>
                  <AlertDialogDescription>
                    <p className="mb-4">
                      The Digital Mitraa AI Assistant is powered by OpenAI's GPT-4o model. It can help you with:
                    </p>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Content creation and ideation</li>
                      <li>Marketing strategy development</li>
                      <li>SEO recommendations</li>
                      <li>Social media planning</li>
                      <li>Email marketing campaigns</li>
                      <li>Competitive analysis</li>
                    </ul>
                    <p className="mt-4">
                      Your conversations are securely stored and can be accessed from your dashboard anytime.
                    </p>
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Close</AlertDialogCancel>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-6">
          <Tabs value={tab} onValueChange={setTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="chat">Chat</TabsTrigger>
              <TabsTrigger value="prompts">Prompt Ideas</TabsTrigger>
            </TabsList>
            <TabsContent value="chat" className="space-y-4">
              <Card className="border-gray-200 h-[calc(100vh-240px)]">
                <CardHeader className="px-6 pt-6 pb-4 border-b">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center mr-3">
                        <Bot className="h-5 w-5 text-primary-600" />
                      </div>
                      <div>
                        <CardTitle>Digital Mitraa Assistant</CardTitle>
                        <CardDescription>Powered by GPT-4o</CardDescription>
                      </div>
                    </div>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          Clear Chat
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This will permanently delete all your messages. This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={() => clearChatMutation.mutate()}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            {clearChatMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Deleting...
                              </>
                            ) : (
                              "Delete All"
                            )}
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </CardHeader>
                <CardContent className="p-0 flex flex-col h-[calc(100%-140px)]">
                  <ScrollArea className="flex-1 p-6">
                    <div className="space-y-6" ref={scrollAreaRef}>
                      {isLoading ? (
                        <div className="flex items-start space-x-3">
                          <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center">
                            <Bot className="h-4 w-4 text-primary-600" />
                          </div>
                          <div className="bg-gray-100 rounded-lg p-4 max-w-[80%] relative">
                            <div className="flex items-center space-x-2">
                              <Loader2 className="h-4 w-4 animate-spin" />
                              <p>Loading conversation...</p>
                            </div>
                          </div>
                        </div>
                      ) : messages?.length ? (
                        messages.map((msg, index) => (
                          <div
                            key={index}
                            className={`flex items-start ${
                              msg.role === "user" ? "justify-end" : ""
                            }`}
                          >
                            {msg.role !== "user" && (
                              <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center mr-3">
                                <Bot className="h-4 w-4 text-primary-600" />
                              </div>
                            )}
                            <div
                              className={`${
                                msg.role === "user"
                                  ? "bg-primary-100 text-primary-900"
                                  : "bg-gray-100 text-gray-900"
                              } rounded-lg p-4 max-w-[80%] relative`}
                            >
                              <p className="whitespace-pre-wrap">{msg.content}</p>
                              <span className="text-xs text-gray-500 mt-1 block">
                                {new Date(msg.createdAt).toLocaleTimeString([], {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </span>
                            </div>
                            {msg.role === "user" && (
                              <div className="h-8 w-8 rounded-full bg-gray-300 flex items-center justify-center ml-3">
                                <User className="h-4 w-4 text-gray-600" />
                              </div>
                            )}
                          </div>
                        ))
                      ) : (
                        <div className="flex items-start space-x-3">
                          <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center">
                            <Bot className="h-4 w-4 text-primary-600" />
                          </div>
                          <div className="bg-gray-100 rounded-lg p-4 max-w-[80%] relative">
                            <p>
                              👋 Hi there! I'm your AI marketing assistant. I can help with content creation, SEO strategy, social media planning, and more. How can I assist you today?
                            </p>
                          </div>
                        </div>
                      )}
                      {sendMessageMutation.isPending && (
                        <div className="flex items-start justify-end">
                          <div className="bg-primary-100 text-primary-900 rounded-lg p-4 max-w-[80%] relative">
                            <p>{message}</p>
                          </div>
                          <div className="h-8 w-8 rounded-full bg-gray-300 flex items-center justify-center ml-3">
                            <User className="h-4 w-4 text-gray-600" />
                          </div>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                  <div className="p-4 border-t bg-white">
                    <form onSubmit={handleSendMessage} className="flex space-x-2">
                      <Input
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="Type your message here..."
                        className="flex-1"
                        ref={inputRef}
                        disabled={sendMessageMutation.isPending}
                      />
                      <Button
                        type="submit"
                        disabled={sendMessageMutation.isPending || !message.trim()}
                      >
                        {sendMessageMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Send className="h-4 w-4" />
                        )}
                      </Button>
                    </form>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="prompts">
              <Card>
                <CardHeader>
                  <CardTitle>Marketing Prompt Ideas</CardTitle>
                  <CardDescription>
                    Click on any prompt to quickly start a conversation with the AI assistant.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {marketingPrompts.map((prompt, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        className="justify-start h-auto py-4 px-4 text-left whitespace-normal"
                        onClick={() => {
                          setMessage(prompt);
                          setTab("chat");
                          if (inputRef.current) {
                            inputRef.current.focus();
                          }
                        }}
                      >
                        <span>{prompt}</span>
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>How to Get the Most from Your AI Assistant</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-medium text-lg mb-2">Be Specific</h3>
                    <p className="text-gray-600">
                      The more details you provide, the better the AI can tailor its responses to your needs. Include your industry, target audience, and specific goals.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-2">Iterative Refinement</h3>
                    <p className="text-gray-600">
                      Don't hesitate to ask the AI to refine or modify its previous responses. You can say "Make this more engaging" or "Simplify this content for beginners."
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-2">Ask for Examples</h3>
                    <p className="text-gray-600">
                      When discussing marketing strategies, ask for specific examples that apply to your situation to make concepts more concrete.
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium text-lg mb-2">Format Requests</h3>
                    <p className="text-gray-600">
                      You can ask for specific formats like "Create a bulleted list of SEO tips" or "Write this as a social media post for LinkedIn."
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </DashboardLayout>
  );
}
