import React from 'react';
import { HeroSection } from '@/components/home/hero-section';
import { ServicesSection } from '@/components/home/services-section';
import { PartnerSection } from '@/components/home/partner-section';
import { ContactSection } from '@/components/home/contact-section';
import { BlogSection } from '@/components/home/blog-section';
import { CTASection } from '@/components/home/cta-section';

export default function HomePage() {
  return (
    <div>
      <HeroSection />
      <ServicesSection />
      <PartnerSection />
      <ContactSection />
      <BlogSection />
      <CTASection />
    </div>
  );
}