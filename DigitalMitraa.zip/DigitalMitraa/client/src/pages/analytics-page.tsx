import { useState } from "react";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { ArrowDown, ArrowUp, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

// Sample data - in a real app, this would come from an API
const trafficData = [
  { month: "Jan", users: 4000, sessions: 6000, pageviews: 9800 },
  { month: "Feb", users: 5000, sessions: 7500, pageviews: 12000 },
  { month: "Mar", users: 6000, sessions: 9000, pageviews: 15000 },
  { month: "Apr", users: 7000, sessions: 10500, pageviews: 18000 },
  { month: "May", users: 8000, sessions: 12000, pageviews: 21000 },
  { month: "Jun", users: 9000, sessions: 13500, pageviews: 24000 },
  { month: "Jul", users: 10000, sessions: 15000, pageviews: 27000 },
  { month: "Aug", users: 11000, sessions: 16500, pageviews: 30000 },
  { month: "Sep", users: 12000, sessions: 18000, pageviews: 33000 },
  { month: "Oct", users: 13000, sessions: 19500, pageviews: 36000 },
  { month: "Nov", users: 14000, sessions: 21000, pageviews: 39000 },
  { month: "Dec", users: 15000, sessions: 22500, pageviews: 42000 },
];

const conversionData = [
  { month: "Jan", rate: 2.3 },
  { month: "Feb", rate: 2.5 },
  { month: "Mar", rate: 2.7 },
  { month: "Apr", rate: 3.1 },
  { month: "May", rate: 3.3 },
  { month: "Jun", rate: 3.5 },
  { month: "Jul", rate: 3.8 },
  { month: "Aug", rate: 4.0 },
  { month: "Sep", rate: 4.2 },
  { month: "Oct", rate: 4.5 },
  { month: "Nov", rate: 4.7 },
  { month: "Dec", rate: 5.0 },
];

const channelData = [
  { name: "Organic Search", value: 40 },
  { name: "Direct", value: 25 },
  { name: "Social Media", value: 20 },
  { name: "Referral", value: 10 },
  { name: "Email", value: 5 },
];

const deviceData = [
  { name: "Desktop", value: 45 },
  { name: "Mobile", value: 40 },
  { name: "Tablet", value: 15 },
];

const socialMediaData = [
  { name: "Facebook", followers: 5200, engagement: 3.8 },
  { name: "Instagram", followers: 7500, engagement: 4.2 },
  { name: "Twitter", followers: 3800, engagement: 2.6 },
  { name: "LinkedIn", followers: 4500, engagement: 3.1 },
  { name: "YouTube", followers: 2200, engagement: 5.3 },
];

const COLORS = [
  "#6366F1", // primary
  "#0EA5E9", // secondary
  "#8B5CF6", // purple
  "#EC4899", // pink
  "#34D399", // green
];

export default function AnalyticsPage() {
  const [timeframe, setTimeframe] = useState("year");
  const [tab, setTab] = useState("overview");

  // This would be real metrics from an API in a production environment
  const metrics = [
    {
      name: "Website Traffic",
      value: "45,289",
      change: 12.5,
      isPositive: true,
    },
    {
      name: "Conversion Rate",
      value: "4.6%",
      change: 0.8,
      isPositive: true,
    },
    {
      name: "Avg. Session Duration",
      value: "3:24",
      change: 5.2,
      isPositive: true,
    },
    {
      name: "Bounce Rate",
      value: "35.8%",
      change: 2.3,
      isPositive: false,
    },
  ];

  return (
    <DashboardLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">Analytics</h1>
              <p className="mt-1 text-sm text-gray-500">
                Track and analyze your digital marketing performance.
              </p>
            </div>
            <div className="mt-4 md:mt-0 flex space-x-3">
              <Select
                value={timeframe}
                onValueChange={setTimeframe}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select timeframe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">Last 7 days</SelectItem>
                  <SelectItem value="month">Last 30 days</SelectItem>
                  <SelectItem value="quarter">Last 90 days</SelectItem>
                  <SelectItem value="year">Last 12 months</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 mt-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {metrics.map((metric, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-gray-500">{metric.name}</p>
                      <p className="text-2xl font-semibold mt-1">{metric.value}</p>
                    </div>
                    <div className={`flex items-center ${metric.isPositive ? 'text-green-600' : 'text-red-600'}`}>
                      {metric.isPositive ? (
                        <ArrowUp className="h-4 w-4 mr-1" />
                      ) : (
                        <ArrowDown className="h-4 w-4 mr-1" />
                      )}
                      <span>{metric.change}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Tabs value={tab} onValueChange={setTab}>
            <TabsList className="mb-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="traffic">Traffic</TabsTrigger>
              <TabsTrigger value="conversions">Conversions</TabsTrigger>
              <TabsTrigger value="social">Social Media</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Website Traffic</CardTitle>
                    <CardDescription>
                      Website users, sessions, and pageviews over time
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={trafficData}>
                          <defs>
                            <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#6366F1" stopOpacity={0.8}/>
                              <stop offset="95%" stopColor="#6366F1" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorSessions" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#0EA5E9" stopOpacity={0.8}/>
                              <stop offset="95%" stopColor="#0EA5E9" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <XAxis dataKey="month" />
                          <YAxis />
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <Tooltip />
                          <Legend />
                          <Area
                            type="monotone"
                            dataKey="users"
                            stroke="#6366F1"
                            fillOpacity={1}
                            fill="url(#colorUsers)"
                            name="Users"
                          />
                          <Area
                            type="monotone"
                            dataKey="sessions"
                            stroke="#0EA5E9"
                            fillOpacity={1}
                            fill="url(#colorSessions)"
                            name="Sessions"
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Traffic Sources</CardTitle>
                    <CardDescription>
                      Where your website visitors are coming from
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={channelData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {channelData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => `${value}%`} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Conversion Rate Trend</CardTitle>
                    <CardDescription>
                      How your conversion rate has evolved over time
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={conversionData}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip formatter={(value) => `${value}%`} />
                          <Legend />
                          <Line
                            type="monotone"
                            dataKey="rate"
                            stroke="#6366F1"
                            name="Conversion Rate (%)"
                            strokeWidth={2}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Device Breakdown</CardTitle>
                    <CardDescription>
                      Types of devices used to visit your website
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={deviceData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {deviceData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => `${value}%`} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Traffic Tab */}
            <TabsContent value="traffic">
              <div className="grid grid-cols-1 gap-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Traffic Trends</CardTitle>
                    <CardDescription>
                      Detailed breakdown of website traffic metrics
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-96">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={trafficData}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="users" name="Users" fill="#6366F1" />
                          <Bar dataKey="sessions" name="Sessions" fill="#0EA5E9" />
                          <Bar dataKey="pageviews" name="Pageviews" fill="#8B5CF6" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <Card>
                    <CardHeader>
                      <CardTitle>Page Performance</CardTitle>
                      <CardDescription>
                        Most visited pages on your website
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {[
                          { page: "/home", views: 12583, time: "2:45" },
                          { page: "/services", views: 8762, time: "3:12" },
                          { page: "/pricing", views: 5439, time: "4:01" },
                          { page: "/blog", views: 4271, time: "2:37" },
                          { page: "/contact", views: 2984, time: "1:53" },
                        ].map((item, i) => (
                          <div key={i} className="flex justify-between items-center">
                            <div>
                              <p className="font-medium">{item.page}</p>
                              <p className="text-sm text-gray-500">Avg. Time: {item.time}</p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">{item.views.toLocaleString()}</p>
                              <p className="text-sm text-gray-500">Pageviews</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Referral Sources</CardTitle>
                      <CardDescription>
                        Top websites sending traffic to your site
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {[
                          { source: "google.com", sessions: 9427, conversion: "3.2%" },
                          { source: "facebook.com", sessions: 5218, conversion: "2.8%" },
                          { source: "linkedin.com", sessions: 3845, conversion: "4.1%" },
                          { source: "twitter.com", sessions: 2341, conversion: "1.9%" },
                          { source: "instagram.com", sessions: 1987, conversion: "3.5%" },
                        ].map((item, i) => (
                          <div key={i} className="flex justify-between items-center">
                            <div>
                              <p className="font-medium">{item.source}</p>
                              <p className="text-sm text-gray-500">Conv: {item.conversion}</p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">{item.sessions.toLocaleString()}</p>
                              <p className="text-sm text-gray-500">Sessions</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* Conversions Tab */}
            <TabsContent value="conversions">
              <div className="grid grid-cols-1 gap-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Conversion Rate by Channel</CardTitle>
                    <CardDescription>
                      How different traffic sources are converting
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[
                            { name: "Organic", rate: 3.2 },
                            { name: "Paid Search", rate: 4.7 },
                            { name: "Social", rate: 2.8 },
                            { name: "Email", rate: 6.3 },
                            { name: "Direct", rate: 3.5 },
                            { name: "Referral", rate: 4.1 },
                          ]}
                        >
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip formatter={(value) => `${value}%`} />
                          <Bar dataKey="rate" name="Conversion Rate (%)" fill="#6366F1" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <Card>
                    <CardHeader>
                      <CardTitle>Funnel Analysis</CardTitle>
                      <CardDescription>
                        Conversion funnel visualization
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {[
                          { stage: "Page Visit", users: 45289, percent: "100%" },
                          { stage: "Product View", users: 28376, percent: "62.7%" },
                          { stage: "Add to Cart", users: 12483, percent: "27.6%" },
                          { stage: "Checkout", users: 8395, percent: "18.5%" },
                          { stage: "Purchase", users: 5476, percent: "12.1%" },
                        ].map((item, i) => (
                          <div key={i}>
                            <div className="flex justify-between items-center mb-1">
                              <div>
                                <p className="font-medium">{item.stage}</p>
                              </div>
                              <div className="text-right">
                                <p className="font-medium">{item.users.toLocaleString()}</p>
                                <p className="text-sm text-gray-500">{item.percent}</p>
                              </div>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div
                                className="bg-primary-600 h-2.5 rounded-full"
                                style={{ width: item.percent }}
                              ></div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Goal Completions</CardTitle>
                      <CardDescription>
                        Performance of conversion goals
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {[
                          { goal: "Newsletter Signup", completions: 2874, rate: "6.3%" },
                          { goal: "Free Trial", completions: 1523, rate: "3.4%" },
                          { goal: "Product Purchase", completions: 857, rate: "1.9%" },
                          { goal: "Demo Request", completions: 642, rate: "1.4%" },
                          { goal: "Contact Form", completions: 1289, rate: "2.8%" },
                        ].map((item, i) => (
                          <div key={i} className="flex justify-between items-center">
                            <div>
                              <p className="font-medium">{item.goal}</p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">{item.completions.toLocaleString()}</p>
                              <p className="text-sm text-gray-500">Conv. Rate: {item.rate}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>

            {/* Social Media Tab */}
            <TabsContent value="social">
              <div className="grid grid-cols-1 gap-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Social Media Performance</CardTitle>
                    <CardDescription>
                      Followers and engagement rates across platforms
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={socialMediaData}
                          margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="name" />
                          <YAxis yAxisId="left" orientation="left" />
                          <YAxis yAxisId="right" orientation="right" />
                          <Tooltip />
                          <Legend />
                          <Bar
                            yAxisId="left"
                            dataKey="followers"
                            name="Followers"
                            fill="#6366F1"
                          />
                          <Line
                            yAxisId="right"
                            type="monotone"
                            dataKey="engagement"
                            name="Engagement Rate (%)"
                            stroke="#0EA5E9"
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <Card>
                    <CardHeader>
                      <CardTitle>Top Performing Posts</CardTitle>
                      <CardDescription>
                        Your most engaging social media content
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {[
                          { platform: "Instagram", content: "Product Showcase", engagement: 2874, rate: "5.3%" },
                          { platform: "Facebook", content: "Customer Testimonial", engagement: 1942, rate: "4.7%" },
                          { platform: "LinkedIn", content: "Industry Report", engagement: 1523, rate: "6.2%" },
                          { platform: "Twitter", content: "Product Launch", engagement: 1289, rate: "3.8%" },
                          { platform: "YouTube", content: "Tutorial Video", engagement: 2135, rate: "7.1%" },
                        ].map((item, i) => (
                          <div key={i} className="flex justify-between items-center">
                            <div>
                              <p className="font-medium">{item.content}</p>
                              <p className="text-sm text-gray-500">{item.platform}</p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">{item.engagement.toLocaleString()}</p>
                              <p className="text-sm text-gray-500">Eng. Rate: {item.rate}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Audience Growth</CardTitle>
                      <CardDescription>
                        Follower growth across social platforms
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart
                            data={[
                              { month: "Jan", facebook: 4200, instagram: 6300, twitter: 3100, linkedin: 3800 },
                              { month: "Feb", facebook: 4400, instagram: 6500, twitter: 3200, linkedin: 3900 },
                              { month: "Mar", facebook: 4500, instagram: 6700, twitter: 3300, linkedin: 4000 },
                              { month: "Apr", facebook: 4600, instagram: 6900, twitter: 3400, linkedin: 4100 },
                              { month: "May", facebook: 4800, instagram: 7100, twitter: 3500, linkedin: 4200 },
                              { month: "Jun", facebook: 5000, instagram: 7300, twitter: 3600, linkedin: 4300 },
                              { month: "Jul", facebook: 5200, instagram: 7500, twitter: 3800, linkedin: 4500 },
                            ]}
                          >
                            <CartesianGrid strokeDasharray="3 3" vertical={false} />
                            <XAxis dataKey="month" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="facebook" name="Facebook" stroke="#6366F1" />
                            <Line type="monotone" dataKey="instagram" name="Instagram" stroke="#EC4899" />
                            <Line type="monotone" dataKey="twitter" name="Twitter" stroke="#0EA5E9" />
                            <Line type="monotone" dataKey="linkedin" name="LinkedIn" stroke="#8B5CF6" />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </DashboardLayout>
  );
}
