import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Search, Bot, BarChart2, Share2, Mail, CheckSquare, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function ServicesPage() {
  const services = [
    {
      title: "Search Engine Optimization",
      description: "Increase your website's visibility in search engines and drive organic traffic with our comprehensive SEO services.",
      icon: Search,
      bgColor: "bg-primary-100",
      iconColor: "text-primary-600",
      features: [
        "Keyword Research & Strategy",
        "On-Page SEO Optimization",
        "Technical SEO Audits",
        "Link Building & Authority Development",
        "Local SEO for Small Businesses",
        "Analytics & Reporting"
      ]
    },
    {
      title: "AI Marketing Assistant",
      description: "Leverage the power of artificial intelligence to create data-driven marketing campaigns that convert.",
      icon: Bot,
      bgColor: "bg-secondary-100",
      iconColor: "text-secondary-600",
      features: [
        "AI-Powered Content Creation",
        "Smart Email Campaign Automation",
        "Predictive Analytics",
        "24/7 Customer Support Chatbots",
        "Personalized Marketing Recommendations",
        "Market Trend Analysis"
      ]
    },
    {
      title: "Performance Analytics",
      description: "Make data-driven decisions with our comprehensive analytics tools that track and visualize your marketing performance.",
      icon: BarChart2,
      bgColor: "bg-purple-100",
      iconColor: "text-purple-600",
      features: [
        "Real-Time Dashboard",
        "Custom Report Creation",
        "Conversion Tracking",
        "User Behavior Analysis",
        "ROI Measurement",
        "Competitive Benchmarking"
      ]
    },
    {
      title: "Social Media Management",
      description: "Build a strong social presence with our comprehensive social media management solutions.",
      icon: Share2,
      bgColor: "bg-pink-100",
      iconColor: "text-pink-600",
      features: [
        "Content Calendar Creation",
        "Post Scheduling & Publishing",
        "Community Engagement",
        "Social Media Advertising",
        "Influencer Partnership Management",
        "Performance Reporting"
      ]
    },
    {
      title: "Email Marketing",
      description: "Create, automate, and analyze email campaigns that convert subscribers into customers with our email marketing services.",
      icon: Mail,
      bgColor: "bg-green-100",
      iconColor: "text-green-600",
      features: [
        "Email Template Design",
        "List Segmentation & Management",
        "Automated Drip Campaigns",
        "A/B Testing",
        "Deliverability Optimization",
        "Performance Analytics"
      ]
    },
    {
      title: "Project Management",
      description: "Keep your marketing initiatives organized and on track with our powerful project management tools.",
      icon: CheckSquare,
      bgColor: "bg-yellow-100",
      iconColor: "text-yellow-600",
      features: [
        "Task Assignment & Tracking",
        "Timeline Management",
        "Resource Allocation",
        "Team Collaboration Tools",
        "Project Templates",
        "Progress Reporting"
      ]
    }
  ];

  return (
    <MainLayout>
      <div className="bg-gradient-to-br from-primary-700 to-secondary-600 py-16 md:py-24 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl md:text-5xl font-bold mb-4">Our Digital Marketing Services</h1>
          <p className="text-xl md:text-2xl max-w-3xl mx-auto opacity-90">
            Comprehensive solutions to grow your business online
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="border border-gray-100">
              <CardHeader>
                <div className={`w-14 h-14 rounded-full ${service.bgColor} flex items-center justify-center mb-4`}>
                  <service.icon className={service.iconColor} size={24} />
                </div>
                <CardTitle className="text-2xl">{service.title}</CardTitle>
                <CardDescription>{service.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {service.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      <div className="flex-shrink-0 mt-1">
                        <svg className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="ml-2 text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-6">
                  <Link href="/contact">
                    <Button className="w-full">
                      Learn More <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-20 text-center">
          <h2 className="text-3xl font-bold mb-6">Need a Custom Solution?</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto mb-8">
            Every business is unique. Contact us to discuss how we can create a tailored digital marketing strategy for your specific needs.
          </p>
          <Link href="/contact">
            <Button size="lg">
              Contact Us
            </Button>
          </Link>
        </div>
      </div>
    </MainLayout>
  );
}
