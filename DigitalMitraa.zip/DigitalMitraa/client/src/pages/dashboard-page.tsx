import { DashboardLayout } from "@/components/layout/dashboard-layout";
import { StatsCards } from "@/components/dashboard/stats-cards";
import { TrafficAnalytics } from "@/components/dashboard/traffic-analytics";
import { AiAssistant } from "@/components/dashboard/ai-assistant";
import { ProjectManagement } from "@/components/dashboard/project-management";
import { RecentActivity } from "@/components/dashboard/recent-activity";
import { useAuth } from "@/hooks/use-auth";

export default function DashboardPage() {
  const { user } = useAuth();

  return (
    <DashboardLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <div className="py-4">
            {/* Stats Cards */}
            <StatsCards />
            
            {/* Main Dashboard Sections */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <TrafficAnalytics />
              <AiAssistant />
            </div>
            
            {/* Project Management & Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
              <ProjectManagement />
              <RecentActivity />
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
