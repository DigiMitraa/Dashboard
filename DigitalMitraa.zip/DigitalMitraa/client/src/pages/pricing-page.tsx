import { useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, HelpCircle } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Link } from "wouter";

export default function PricingPage() {
  const [billingCycle, setBillingCycle] = useState<string>("monthly");

  const plans = [
    {
      name: "Starter",
      description: "Perfect for small businesses",
      monthlyPrice: 49,
      yearlyPrice: 470,
      features: [
        "Basic SEO tools",
        "Social media integration",
        "5 AI marketing suggestions per month",
        "Basic analytics dashboard",
        "Email support",
        "1 user"
      ],
      isPopular: false,
      cta: "Get Started"
    },
    {
      name: "Professional",
      description: "For growing businesses",
      monthlyPrice: 99,
      yearlyPrice: 950,
      features: [
        "Advanced SEO tools",
        "Complete social media suite",
        "25 AI marketing suggestions per month",
        "Full analytics dashboard",
        "Priority email & chat support",
        "Content calendar",
        "5 users"
      ],
      isPopular: true,
      cta: "Get Started"
    },
    {
      name: "Enterprise",
      description: "For large organizations",
      monthlyPrice: 249,
      yearlyPrice: 2390,
      features: [
        "All Professional features",
        "Unlimited AI marketing suggestions",
        "Custom reporting",
        "API access",
        "Dedicated account manager",
        "24/7 phone, email & chat support",
        "Unlimited users"
      ],
      isPopular: false,
      cta: "Contact Sales"
    }
  ];

  const faqs = [
    {
      question: "Can I change my plan later?",
      answer: "Yes, you can upgrade or downgrade your plan at any time. Changes will be reflected in your next billing cycle."
    },
    {
      question: "Is there a free trial available?",
      answer: "Yes, we offer a 14-day free trial for all our plans. No credit card required."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We accept all major credit cards, PayPal, and bank transfers for annual plans."
    },
    {
      question: "Can I cancel my subscription?",
      answer: "Yes, you can cancel your subscription at any time through your account dashboard."
    },
    {
      question: "Is there a setup fee?",
      answer: "No, there are no setup fees for any of our plans."
    },
    {
      question: "Do you offer custom plans?",
      answer: "Yes, we offer custom plans for businesses with specific needs. Contact our sales team for more information."
    }
  ];

  return (
    <MainLayout>
      <div className="bg-gradient-to-br from-primary-700 to-secondary-600 py-16 md:py-24 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl md:text-5xl font-bold mb-4">Simple, Transparent Pricing</h1>
          <p className="text-xl md:text-2xl max-w-3xl mx-auto opacity-90">
            Choose the perfect plan for your business needs
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 -mt-8">
        <div className="bg-white p-8 rounded-xl shadow-lg mb-16">
          <div className="flex justify-center mb-8">
            <Tabs value={billingCycle} onValueChange={setBillingCycle}>
              <TabsList>
                <TabsTrigger value="monthly">Monthly Billing</TabsTrigger>
                <TabsTrigger value="yearly">Yearly Billing (Save 20%)</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <div 
                key={index} 
                className={`bg-white rounded-2xl shadow-md ${plan.isPopular ? 'border-2 border-primary-500 md:scale-105' : 'border border-gray-100'} overflow-hidden relative`}
              >
                {plan.isPopular && (
                  <div className="absolute top-0 inset-x-0 bg-primary-500 text-white text-center py-1 text-sm font-medium">
                    Most Popular
                  </div>
                )}
                <div className={`p-8 ${plan.isPopular ? 'pt-12' : ''}`}>
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <p className="text-gray-500 mb-6">{plan.description}</p>
                  <div className="mb-6">
                    <span className="text-4xl font-bold">
                      ${billingCycle === "monthly" ? plan.monthlyPrice : plan.yearlyPrice}
                    </span>
                    <span className="text-gray-500">/{billingCycle === "monthly" ? "month" : "year"}</span>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-center">
                        <Check className="text-green-500 mr-2" size={16} />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link href="/auth">
                    <Button 
                      className={`w-full ${plan.isPopular ? 'bg-primary-600 hover:bg-primary-700 text-white' : 'bg-white text-primary-600 border border-primary-600 hover:bg-gray-50'}`}
                      variant={plan.isPopular ? "default" : "outline"}
                    >
                      {plan.cta}
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-12">Compare Plans</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white border border-gray-200 divide-y divide-gray-200">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Features</th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Starter</th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Professional</th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Enterprise</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">SEO Tools</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Basic</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Advanced</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Advanced</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">AI Suggestions</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">5/month</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">25/month</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Unlimited</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Analytics Dashboard</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Basic</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Full</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Custom</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Support</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Email</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Email & Chat</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">24/7 All Channels</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">API Access</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">—</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">—</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                    <Check className="inline text-green-500" size={16} />
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Dedicated Account Manager</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">—</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">—</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                    <Check className="inline text-green-500" size={16} />
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Users</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">1</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">5</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Unlimited</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div>
          <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {faqs.map((faq, index) => (
              <Card key={index} className="border border-gray-200">
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-2 flex items-center">
                    {faq.question}
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-6 w-6 ml-2">
                            <HelpCircle className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p>{faq.answer}</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </h3>
                  <p className="text-gray-600">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="mt-16 text-center">
          <h2 className="text-2xl font-bold mb-4">Still have questions?</h2>
          <p className="text-gray-600 mb-6">Our team is here to help. Contact us for more information.</p>
          <Link href="/contact">
            <Button>Contact Sales</Button>
          </Link>
        </div>
      </div>
    </MainLayout>
  );
}
