import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Users, TrendingUp, GitBranch, DollarSign } from "lucide-react";
import { Link } from "wouter";

interface StatsCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  iconBgColor: string;
  iconColor: string;
  linkText: string;
  linkHref: string;
}

function StatsCard({ title, value, icon, iconBgColor, iconColor, linkText, linkHref }: StatsCardProps) {
  return (
    <Card className="dashboard-card overflow-hidden shadow transition duration-300 hover:scale-102">
      <CardContent className="px-4 py-5 sm:p-6">
        <div className="flex items-center">
          <div className={`flex-shrink-0 ${iconBgColor} rounded-md p-3`}>
            {icon}
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">{title}</dt>
              <dd>
                <div className="text-lg font-medium text-gray-900">{value}</div>
              </dd>
            </dl>
          </div>
        </div>
      </CardContent>
      <CardFooter className="bg-gray-50 px-4 py-4 sm:px-6">
        <div className="text-sm">
          <Link href={linkHref}>
            <a className="font-medium text-primary-600 hover:text-primary-500">
              {linkText}<span className="sr-only"> {title.toLowerCase()}</span>
            </a>
          </Link>
        </div>
      </CardFooter>
    </Card>
  );
}

export function StatsCards() {
  const stats = [
    {
      title: "Total Users",
      value: "1,258",
      icon: <Users className="text-primary-600" size={20} />,
      iconBgColor: "bg-primary-100",
      iconColor: "text-primary-600",
      linkText: "View all",
      linkHref: "/dashboard/users"
    },
    {
      title: "Traffic Growth",
      value: "+24.5%",
      icon: <TrendingUp className="text-green-600" size={20} />,
      iconBgColor: "bg-green-100",
      iconColor: "text-green-600",
      linkText: "View analytics",
      linkHref: "/dashboard/analytics"
    },
    {
      title: "Active Projects",
      value: "32",
      icon: <GitBranch className="text-secondary-600" size={20} />,
      iconBgColor: "bg-secondary-100",
      iconColor: "text-secondary-600",
      linkText: "View projects",
      linkHref: "/dashboard/projects"
    },
    {
      title: "Monthly Revenue",
      value: "$12,845",
      icon: <DollarSign className="text-purple-600" size={20} />,
      iconBgColor: "bg-purple-100",
      iconColor: "text-purple-600",
      linkText: "View finances",
      linkHref: "/dashboard/invoicing"
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, index) => (
        <StatsCard key={index} {...stat} />
      ))}
    </div>
  );
}
