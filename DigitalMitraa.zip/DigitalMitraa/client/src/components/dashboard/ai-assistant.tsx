import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, Bot, User } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Message } from "@shared/schema";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";

export function AiAssistant() {
  const [message, setMessage] = useState("");
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: messages, isLoading } = useQuery<Message[]>({
    queryKey: ["/api/messages"],
    refetchInterval: false,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest("POST", "/api/messages", { content });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      setMessage("");
    },
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      sendMessageMutation.mutate(message);
    }
  };

  return (
    <Card className="dashboard-card transition duration-300 hover:scale-102">
      <CardHeader className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <CardTitle className="text-lg leading-6 font-medium">AI Assistant</CardTitle>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6 flex flex-col h-72">
        <ScrollArea className="flex-1 bg-gray-50 rounded-lg p-4 space-y-4">
          {isLoading ? (
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="flex-shrink-0 mr-3">
                  <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center">
                    <Bot className="text-primary-600 h-4 w-4" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Skeleton className="h-12 w-60" />
                </div>
              </div>
              <div className="flex items-start justify-end">
                <div className="space-y-2">
                  <Skeleton className="h-10 w-40 ml-auto" />
                </div>
                <div className="flex-shrink-0 ml-3">
                  <div className="h-8 w-8 rounded-full bg-gray-300" />
                </div>
              </div>
            </div>
          ) : messages?.length ? (
            messages.map((msg, index) => (
              <div key={index} className={`flex items-start ${msg.role === 'user' ? 'justify-end' : ''}`}>
                {msg.role !== 'user' && (
                  <div className="flex-shrink-0 mr-3">
                    <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center">
                      <Bot className="text-primary-600 h-4 w-4" />
                    </div>
                  </div>
                )}
                <div className={`${msg.role === 'user' ? 'bg-primary-100' : 'bg-gray-200'} rounded-lg p-3 max-w-xs`}>
                  <p className="text-sm">{msg.content}</p>
                </div>
                {msg.role === 'user' && (
                  <div className="flex-shrink-0 ml-3">
                    <div className="h-8 w-8 rounded-full bg-gray-300 flex items-center justify-center">
                      <User className="h-4 w-4" />
                    </div>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="flex items-start">
              <div className="flex-shrink-0 mr-3">
                <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center">
                  <Bot className="text-primary-600 h-4 w-4" />
                </div>
              </div>
              <div className="bg-gray-200 rounded-lg p-3 max-w-xs">
                <p className="text-sm">Hello! I'm your AI marketing assistant. How can I help you today?</p>
              </div>
            </div>
          )}
        </ScrollArea>
        <form onSubmit={handleSendMessage} className="mt-4 flex">
          <Input
            type="text"
            placeholder="Ask your marketing assistant..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="flex-1 focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
          />
          <Button 
            type="submit" 
            className="ml-3" 
            size="icon"
            disabled={sendMessageMutation.isPending}
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
