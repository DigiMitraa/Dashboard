import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Activity } from "@shared/schema";
import { UserPlus, DollarSign, GitBranch, MessageSquare } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { formatDistance } from "date-fns";

export function RecentActivity() {
  const { data: activities, isLoading } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
    refetchInterval: false,
  });

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'user-signup':
        return { icon: UserPlus, bgColor: 'bg-primary-500' };
      case 'payment':
        return { icon: DollarSign, bgColor: 'bg-green-500' };
      case 'project-update':
        return { icon: GitBranch, bgColor: 'bg-secondary-500' };
      case 'comment':
        return { icon: MessageSquare, bgColor: 'bg-purple-500' };
      default:
        return { icon: MessageSquare, bgColor: 'bg-gray-500' };
    }
  };

  return (
    <Card className="dashboard-card transition duration-300 hover:scale-102">
      <CardHeader className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <CardTitle className="text-lg leading-6 font-medium">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6">
        <div className="flow-root">
          <ul role="list" className="-mb-8">
            {isLoading ? (
              [1, 2, 3, 4].map((i) => (
                <li key={i}>
                  <div className="relative pb-8">
                    <span className="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true"></span>
                    <div className="relative flex items-start space-x-3">
                      <div className="relative">
                        <Skeleton className="h-10 w-10 rounded-full" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div>
                          <div className="text-sm">
                            <Skeleton className="h-4 w-48" />
                          </div>
                          <Skeleton className="h-3 w-24 mt-1" />
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
              ))
            ) : activities?.length ? (
              activities.map((activity, index) => {
                const { icon: Icon, bgColor } = getActivityIcon(activity.type);
                const isLast = index === activities.length - 1;
                
                return (
                  <li key={activity.id}>
                    <div className="relative pb-8">
                      {!isLast && <span className="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true"></span>}
                      <div className="relative flex items-start space-x-3">
                        <div className="relative">
                          <div className={`h-10 w-10 rounded-full ${bgColor} flex items-center justify-center ring-8 ring-white`}>
                            <Icon className="text-white" size={16} />
                          </div>
                        </div>
                        <div className="min-w-0 flex-1">
                          <div>
                            <div className="text-sm" dangerouslySetInnerHTML={{ 
                              __html: activity.description
                            }} />
                            <p className="mt-0.5 text-sm text-gray-500">
                              {formatDistance(new Date(activity.createdAt), new Date(), { addSuffix: true })}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </li>
                );
              })
            ) : (
              <li className="text-center text-gray-500 py-4">No recent activity</li>
            )}
          </ul>
        </div>
      </CardContent>
      <CardFooter className="mt-6 text-center px-6 py-4 border-t border-gray-200">
        <Link href="/dashboard/activities">
          <a className="text-sm font-medium text-primary-600 hover:text-primary-500">
            View all activity
          </a>
        </Link>
      </CardFooter>
    </Card>
  );
}
