import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ArrowUp, ArrowDown } from "lucide-react";

const data = [
  { name: 'Jan', users: 4000, sessions: 5400, pageviews: 9800 },
  { name: 'Feb', users: 6000, sessions: 8000, pageviews: 12000 },
  { name: 'Mar', users: 8000, sessions: 10000, pageviews: 15000 },
  { name: 'Apr', users: 9000, sessions: 12000, pageviews: 18000 },
  { name: 'May', users: 11000, sessions: 14000, pageviews: 21000 },
  { name: 'Jun', users: 12000, sessions: 15000, pageviews: 24000 },
  { name: 'Jul', users: 14000, sessions: 18000, pageviews: 27000 },
  { name: 'Aug', users: 16000, sessions: 21000, pageviews: 30000 },
  { name: 'Sep', users: 18000, sessions: 24000, pageviews: 33000 },
  { name: 'Oct', users: 20000, sessions: 27000, pageviews: 36000 },
  { name: 'Nov', users: 22000, sessions: 30000, pageviews: 39000 },
  { name: 'Dec', users: 25400, sessions: 42100, pageviews: 45000 },
];

export function TrafficAnalytics() {
  const metrics = [
    { label: 'Users', value: '25.4K', change: 12, isPositive: true },
    { label: 'Sessions', value: '42.1K', change: 8, isPositive: true },
    { label: 'Bounce Rate', value: '42%', change: 3, isPositive: false },
    { label: 'Avg. Time', value: '2:32', change: 15, isPositive: true },
  ];

  return (
    <Card className="dashboard-card col-span-2 transition duration-300 hover:scale-102">
      <CardHeader className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <CardTitle className="text-lg leading-6 font-medium">Traffic Analytics</CardTitle>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6">
        <div className="h-72 mb-4">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorSessions" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--chart-2))" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="hsl(var(--chart-2))" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value / 1000}k`} />
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <Tooltip />
              <Area type="monotone" dataKey="users" stroke="hsl(var(--chart-1))" fillOpacity={1} fill="url(#colorUsers)" />
              <Area type="monotone" dataKey="sessions" stroke="hsl(var(--chart-2))" fillOpacity={1} fill="url(#colorSessions)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="grid grid-cols-4 gap-4 text-center">
          {metrics.map((metric, index) => (
            <div key={index}>
              <p className="text-sm font-medium text-gray-500">{metric.label}</p>
              <p className="text-xl font-semibold text-gray-900">{metric.value}</p>
              <p className={`text-xs flex items-center justify-center ${metric.isPositive ? 'text-green-600' : 'text-red-600'}`}>
                {metric.isPositive ? <ArrowUp size={12} /> : <ArrowDown size={12} />} {metric.change}%
              </p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
