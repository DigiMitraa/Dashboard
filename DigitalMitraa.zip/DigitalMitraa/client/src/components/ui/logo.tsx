import { ReactNode } from "react";
import { Link } from "wouter";
import logoImage from "@/assets/logo_transparent.png";

interface LogoProps {
  size?: "sm" | "md" | "lg";
  variant?: "primary" | "white";
  withText?: boolean;
  className?: string;
  children?: ReactNode;
}

export function Logo({ 
  size = "md", 
  variant = "primary", 
  withText = true,
  className = "",
  children
}: LogoProps) {
  const sizeClasses = {
    sm: "h-8",
    md: "h-12",
    lg: "h-16",
  };

  // Set the image size based on the size prop
  const imageSize = {
    sm: "w-auto h-8",
    md: "w-auto h-12",
    lg: "w-auto h-16",
  };

  return (
    <Link href="/">
      <div className={`flex items-center cursor-pointer ${className}`}>
        <div className={`flex flex-col ${withText ? "items-center" : "items-start"}`}>
          <div className="flex items-center">
            {/* Use the imported logo image */}
            <img 
              src={logoImage} 
              alt="Digital Mitraa Logo" 
              className={`${imageSize[size]}`}
            />
          </div>
          {children}
        </div>
      </div>
    </Link>
  );
}