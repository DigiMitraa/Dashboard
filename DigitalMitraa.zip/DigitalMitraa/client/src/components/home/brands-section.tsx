import { SiAirbnb, SiAmazon, SiGoogle, SiApple, SiNetflix, SiSlack } from "react-icons/si";

export function BrandsSection() {
  const brands = [
    { name: "Google", icon: SiGoogle },
    { name: "Amazon", icon: SiAmazon },
    { name: "Apple", icon: SiApple },
    { name: "Airbnb", icon: SiAirbnb },
    { name: "Netflix", icon: SiNetflix },
    { name: "Slack", icon: SiSlack },
  ];

  return (
    <div className="bg-gray-50 py-12 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-center text-gray-500 font-medium mb-8">Trusted by innovative companies worldwide</p>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center justify-items-center opacity-70">
          {brands.map((brand) => (
            <div key={brand.name} className="h-8">
              <brand.icon className="h-8 w-auto text-gray-500" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
