export function HowItWorksSection() {
  const steps = [
    {
      number: 1,
      title: "Sign Up & Connect",
      description: "Create your account and connect your digital platforms in minutes."
    },
    {
      number: 2,
      title: "Get AI Insights",
      description: "Our AI analyzes your digital presence and provides actionable recommendations."
    },
    {
      number: 3,
      title: "Grow Your Business",
      description: "Implement our strategies and watch your digital presence expand."
    }
  ];

  return (
    <div className="bg-gray-50 py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">How Digital Mitraa Works</h2>
          <p className="text-xl text-gray-500 max-w-3xl mx-auto">Our simple three-step process helps transform your digital marketing efforts.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step) => (
            <div key={step.number} className="text-center">
              <div className="w-20 h-20 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 mx-auto mb-6">
                <span className="text-2xl font-bold">{step.number}</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
              <p className="text-gray-500">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
