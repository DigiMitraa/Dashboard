import React from 'react';
import { Button } from '@/components/ui/button';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Phone, Mail, MessageSquare, Bot, Send, ArrowRight } from 'lucide-react';

const contactFormSchema = z.object({
  name: z.string().min(2, 'Name is required'),
  email: z.string().email('Valid email is required'),
  phone: z.string().min(10, 'Valid phone number is required'),
  service: z.string().min(1, 'Please select a service'),
  message: z.string().min(10, 'Message is required'),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

export function ContactSection() {
  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: '',
      email: '',
      phone: '',
      service: '',
      message: '',
    },
  });

  function onSubmit(data: ContactFormValues) {
    console.log(data);
    // In a real application, submit this data to your backend
    alert('Form submitted! We will contact you soon.');
    form.reset();
  }

  const services = [
    { value: 'legal', label: 'Legal Services' },
    { value: 'digital', label: 'Digital Services' },
    { value: 'loan', label: 'Loan Services' },
    { value: 'insurance', label: 'Insurance Services' },
    { value: 'franchisee', label: 'Franchisee Inquiry' },
    { value: 'bank_partner', label: 'Bank Partner Inquiry' },
  ];

  const aiMessages = [
    { sender: 'bot', content: 'Hello! I\'m your Digital Mitraa consultant. How can I assist you today?' },
    { sender: 'user', content: 'I need help with business registration services.' },
    { sender: 'bot', content: 'We offer comprehensive business registration consultancy across multiple categories. This includes company registration, GST, trademark, and more. Which specific service are you interested in?' },
    { sender: 'user', content: 'GST registration for my new business.' },
    { sender: 'bot', content: 'Our consultants specialize in GST registration. The service starts at ₹999, and we handle all documentation and follow-up. Would you like me to connect you with one of our GST consultants to discuss your specific requirements?' },
  ];

  return (
    <section className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Connect with Our Consultants
          </h2>
          <p className="text-lg text-gray-600">
            Get expert advice on any of our service categories from our specialized business consultants
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16">
          {/* Contact Form */}
          <div className="bg-white rounded-xl shadow-lg p-6 md:p-8 order-2 lg:order-1">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">
              Request a Call Back
            </h3>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input placeholder="john@example.com" type="email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="+91 98765 43210" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="service"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Service Interest</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a service" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {services.map((service) => (
                            <SelectItem key={service.value} value={service.value}>
                              {service.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Message</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Tell us about your requirements..." 
                          className="resize-none h-32"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700">
                  Submit Request
                </Button>
              </form>
            </Form>
            
            <div className="mt-8 pt-8 border-t border-gray-200">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start">
                  <Phone className="h-5 w-5 text-indigo-600 mr-3 mt-1" />
                  <div>
                    <h4 className="font-medium text-gray-900">Call Us</h4>
                    <p className="text-gray-600">+91 9876543210</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Mail className="h-5 w-5 text-indigo-600 mr-3 mt-1" />
                  <div>
                    <h4 className="font-medium text-gray-900">Email Us</h4>
                    <p className="text-gray-600">info@digitalmitraa.co.in</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* AI Chatbot Demo */}
          <div className="order-1 lg:order-2">
            <div className="bg-white rounded-xl shadow-lg overflow-hidden h-full flex flex-col">
              <div className="bg-indigo-600 text-white p-6">
                <div className="flex items-center">
                  <Bot className="h-8 w-8 mr-3" />
                  <div>
                    <h3 className="text-xl font-bold">AI Consultancy Assistant</h3>
                    <p className="text-indigo-100 text-sm">Get guidance on all our consultancy services 24/7</p>
                  </div>
                </div>
              </div>
              
              <div className="flex-grow p-6 overflow-y-auto">
                <div className="space-y-4">
                  {aiMessages.map((message, index) => (
                    <div 
                      key={index}
                      className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div 
                        className={`max-w-[80%] rounded-lg p-3 ${
                          message.sender === 'user' 
                            ? 'bg-indigo-600 text-white rounded-tr-none' 
                            : 'bg-gray-100 text-gray-800 rounded-tl-none'
                        }`}
                      >
                        {message.content}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="border-t p-4 bg-gray-50">
                <div className="relative">
                  <Input 
                    placeholder="Type your message..." 
                    className="pr-12"
                  />
                  <Button 
                    size="sm" 
                    className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex justify-between items-center mt-3 text-sm text-gray-500">
                  <div className="flex items-center">
                    <MessageSquare className="h-4 w-4 mr-1" />
                    <span>Ask anything about our services</span>
                  </div>
                  <a href="/ai-assistant" className="text-indigo-600 hover:text-indigo-800 flex items-center font-medium">
                    Full Version
                    <ArrowRight className="h-3 w-3 ml-1" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}