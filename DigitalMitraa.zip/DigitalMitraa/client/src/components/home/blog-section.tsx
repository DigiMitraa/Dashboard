import React from 'react';
import { Link } from 'wouter';
import { ArrowRight, Calendar, User } from 'lucide-react';

export function BlogSection() {
  const blogPosts = [
    {
      id: 1,
      title: 'How Our Consultants Simplify GST Registration',
      excerpt: 'Learn how Digital Mitraa consultants streamline the GST registration process, ensuring compliance and maximizing benefits for businesses.',
      category: 'Legal',
      date: 'Mar 28, 2025',
      author: 'Rajesh Kumar, Senior Consultant',
      readTime: '5 min read',
      image: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?q=80&w=300&h=200&auto=format&fit=crop'
    },
    {
      id: 2,
      title: 'Digital Consultancy: Marketing Solutions for Business Growth',
      excerpt: 'Our digital consultants share effective marketing strategies tailored for local businesses to boost visibility and customer acquisition.',
      category: 'Digital',
      date: 'Mar 25, 2025',
      author: 'Priya Singh, Digital Consultant',
      readTime: '7 min read',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=300&h=200&auto=format&fit=crop'
    },
    {
      id: 3,
      title: 'Financial Consultancy: MSME Loan Application Guidance',
      excerpt: 'Our finance consultants provide a step-by-step guide to MSME loan eligibility and application process to help you secure optimal business funding.',
      category: 'Loans',
      date: 'Mar 22, 2025',
      author: 'Amit Patel, Finance Consultant',
      readTime: '6 min read',
      image: 'https://images.unsplash.com/photo-1579621970588-a35d0e7ab9b6?q=80&w=300&h=200&auto=format&fit=crop'
    }
  ];

  const getCategoryColor = (category: string) => {
    switch(category) {
      case 'Legal':
        return 'bg-indigo-100 text-indigo-800';
      case 'Digital':
        return 'bg-blue-100 text-blue-800';
      case 'Loans':
        return 'bg-emerald-100 text-emerald-800';
      case 'Insurance':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Business Consultancy Insights
            </h2>
            <p className="text-lg text-gray-600">
              Expert articles and updates from our consultants across all service categories
            </p>
          </div>
          
          <Link href="/blog" className="hidden md:inline-flex items-center font-medium text-indigo-600 hover:text-indigo-800">
            View All Articles
            <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post) => (
            <article key={post.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <img 
                  src={post.image} 
                  alt={post.title}
                  className="w-full h-48 object-cover"
                />
                <span className={`absolute top-4 left-4 text-xs font-medium px-2 py-1 rounded ${getCategoryColor(post.category)}`}>
                  {post.category}
                </span>
              </div>
              
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-3">
                  <Calendar className="h-4 w-4 mr-1" />
                  <span className="mr-4">{post.date}</span>
                  <User className="h-4 w-4 mr-1" />
                  <span>{post.author}</span>
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-2 leading-tight">
                  <Link href={`/blog/${post.id}`} className="hover:text-indigo-600">
                    {post.title}
                  </Link>
                </h3>
                
                <p className="text-gray-600 mb-4 line-clamp-3">
                  {post.excerpt}
                </p>
                
                <Link href={`/blog/${post.id}`} className="inline-flex items-center text-indigo-600 font-medium hover:text-indigo-800">
                  Read More
                  <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </div>
            </article>
          ))}
        </div>
        
        <div className="mt-8 text-center md:hidden">
          <Link href="/blog" className="inline-flex items-center font-medium text-indigo-600 hover:text-indigo-800">
            View All Articles
            <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
        
        <div className="mt-16 bg-indigo-50 rounded-xl p-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
            <div className="md:col-span-2">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Subscribe to Our Newsletter
              </h3>
              <p className="text-gray-600 mb-6">
                Get the latest updates on legal and business services, helpful tips, and exclusive offers directly to your inbox.
              </p>
            </div>
            
            <div>
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="Your email address" 
                  className="flex-grow rounded-l-lg border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                />
                <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-r-lg">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}