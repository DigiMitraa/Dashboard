import React from 'react';
import { ChevronRight, Users, Building, ClipboardCheck, Award } from 'lucide-react';

export function WhyChooseSection() {
  const stats = [
    {
      icon: <Building className="h-10 w-10 text-indigo-500" />,
      count: '30+',
      label: 'Franchise Branches',
      description: 'Across India',
    },
    {
      icon: <Users className="h-10 w-10 text-indigo-500" />,
      count: '300+',
      label: 'Bank Tie-ups',
      description: 'Financial partnerships',
    },
    {
      icon: <Award className="h-10 w-10 text-indigo-500" />,
      count: '1 Lakh+',
      label: 'Clients Served',
      description: 'Satisfied customers',
    },
    {
      icon: <ClipboardCheck className="h-10 w-10 text-indigo-500" />,
      count: '99%',
      label: 'Success Rate',
      description: 'In service fulfillment',
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Why Choose Digital Mitraa?
          </h2>
          <p className="text-lg text-gray-600">
            Trusted by businesses across India for comprehensive business services with fast turnaround times and expert assistance.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div 
              key={index}
              className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:border-indigo-200 hover:shadow-xl transition-all"
            >
              <div className="mb-4">{stat.icon}</div>
              <div className="font-bold text-3xl md:text-4xl text-indigo-600 mb-2">{stat.count}</div>
              <div className="font-medium text-xl text-gray-900 mb-1">{stat.label}</div>
              <div className="text-gray-500">{stat.description}</div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gray-50 rounded-xl p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Trusted for Excellence
              </h3>
              <p className="text-gray-600 mb-6">
                Digital Mitraa has earned the trust of businesses nationwide by consistently delivering exceptional service quality and expert assistance for all business needs.
              </p>
              
              <ul className="space-y-3">
                {[
                  'Trusted by businesses for GST, ITR, MSME, Website & Loan Services',
                  'Fastest Service Fulfillment & Expert Assistance',
                  'Comprehensive business solutions under one roof',
                  '24/7 customer support and service tracking'
                ].map((item, index) => (
                  <li key={index} className="flex items-start">
                    <ChevronRight className="h-5 w-5 text-indigo-600 mr-2 mt-0.5" />
                    <span className="text-gray-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="relative">
              <div className="aspect-video bg-indigo-100 rounded-lg overflow-hidden">
                <div className="h-full w-full bg-gradient-to-br from-indigo-500/20 to-blue-500/20 flex items-center justify-center">
                  <div className="bg-white/90 backdrop-blur rounded-lg p-8 max-w-sm text-center">
                    <div className="font-bold text-2xl text-indigo-800 mb-2">Our Core Values</div>
                    <div className="text-gray-600 mb-4">
                      Integrity, Excellence, Innovation, and Customer-First approach in everything we do.
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-indigo-50 p-3 rounded">
                        <div className="font-medium text-indigo-900">Integrity</div>
                      </div>
                      <div className="bg-indigo-50 p-3 rounded">
                        <div className="font-medium text-indigo-900">Excellence</div>
                      </div>
                      <div className="bg-indigo-50 p-3 rounded">
                        <div className="font-medium text-indigo-900">Innovation</div>
                      </div>
                      <div className="bg-indigo-50 p-3 rounded">
                        <div className="font-medium text-indigo-900">Customer-First</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}