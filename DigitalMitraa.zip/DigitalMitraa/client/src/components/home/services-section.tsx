import React from 'react';
import { Link } from 'wouter';
import { ArrowRight, FileText, Globe, Landmark, Shield, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function ServicesSection() {
  const serviceCategories = [
    {
      id: 'legal',
      name: 'Legal Services',
      icon: <FileText className="h-10 w-10 text-indigo-600" />,
      description: 'All your legal documentation needs handled by experts',
      services: [
        'GST Registration',
        'Company Registration',
        'Trademark Registration',
        'FSSAI License',
        'PAN Card',
      ],
      color: 'bg-indigo-50',
      textColor: 'text-indigo-800',
      borderColor: 'border-indigo-200',
      link: '/services/legal'
    },
    {
      id: 'digital',
      name: 'Digital Services',
      icon: <Globe className="h-10 w-10 text-blue-600" />,
      description: 'Build your online presence with our digital solutions',
      services: [
        'Website Development',
        'App Development',
        'SEO & Digital Marketing',
        'Social Media Management',
        'Content Creation',
      ],
      color: 'bg-blue-50',
      textColor: 'text-blue-800',
      borderColor: 'border-blue-200',
      link: '/services/digital'
    },
    {
      id: 'loan',
      name: 'Loan Services',
      icon: <Landmark className="h-10 w-10 text-emerald-600" />,
      description: 'Get easy access to capital with our loan services',
      services: [
        'Business Loans',
        'Personal Loans',
        'Home Loans',
        'Mudra Loans',
        'MSME Loans',
      ],
      color: 'bg-emerald-50',
      textColor: 'text-emerald-800',
      borderColor: 'border-emerald-200',
      link: '/services/loan'
    },
    {
      id: 'insurance',
      name: 'Insurance Services',
      icon: <Shield className="h-10 w-10 text-purple-600" />,
      description: 'Protect what matters most with our insurance solutions',
      services: [
        'Health Insurance',
        'Life Insurance',
        'Vehicle Insurance',
        'Business Insurance',
        'Travel Insurance',
      ],
      color: 'bg-purple-50',
      textColor: 'text-purple-800',
      borderColor: 'border-purple-200',
      link: '/services/insurance'
    },
    {
      id: 'real-estate',
      name: 'Real Estate Services',
      icon: <Home className="h-10 w-10 text-amber-600" />,
      description: 'Find, buy or sell properties with our real estate services',
      services: [
        'Property Registration',
        'Property Documentation',
        'Property Verification',
        'Property Tax Services',
        'Rental Services',
      ],
      color: 'bg-amber-50',
      textColor: 'text-amber-800',
      borderColor: 'border-amber-200',
      link: '/services/real-estate'
    }
  ];

  return (
    <section className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Services
          </h2>
          <p className="text-lg text-gray-600">
            One-stop solution for all your business and personal service needs
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {serviceCategories.map((category) => (
            <div 
              key={category.id} 
              className={`rounded-xl overflow-hidden border ${category.borderColor} transition-all hover:shadow-xl`}
            >
              <div className={`${category.color} p-6`}>
                <div className="mb-4">
                  {category.icon}
                </div>
                <h3 className={`text-xl font-bold mb-2 ${category.textColor}`}>
                  {category.name}
                </h3>
                <p className="text-gray-600 mb-4">
                  {category.description}
                </p>
                <ul className="space-y-2 mb-6">
                  {category.services.map((service, idx) => (
                    <li key={idx} className="flex items-center">
                      <div className="h-1.5 w-1.5 rounded-full bg-green-500 mr-2"></div>
                      <span className="text-gray-700">{service}</span>
                    </li>
                  ))}
                </ul>
                <Link href={category.link}>
                  <Button variant="outline" className="w-full border-gray-300 hover:border-gray-400 text-gray-700">
                    View All Services
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Link href="/services">
            <Button className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 h-auto">
              View All Service Categories
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}