import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowRight, Store, Building2, CheckCircle } from 'lucide-react';

export function PartnerSection() {
  const partnerTypes = [
    {
      type: 'Franchisee',
      icon: <Store className="h-12 w-12 text-indigo-600" />,
      color: 'bg-indigo-50',
      textColor: 'text-indigo-800',
      borderColor: 'border-indigo-200',
      fee: '₹6500 One-Time Fee',
      buttonColor: 'bg-indigo-600 hover:bg-indigo-700',
      benefits: [
        'Become a business consultant',
        'Offer multiple service categories',
        'Develop bank partner network',
        'Complete business setup support',
        'Ongoing training & guidance'
      ],
      link: '/franchisee'
    },
    {
      type: 'Bank Partner',
      icon: <Building2 className="h-12 w-12 text-emerald-600" />,
      color: 'bg-emerald-50',
      textColor: 'text-emerald-800',
      borderColor: 'border-emerald-200',
      fee: 'FREE Registration',
      buttonColor: 'bg-emerald-600 hover:bg-emerald-700',
      benefits: [
        'Refer client leads for all services',
        'Earn commission on conversions',
        'Multiple service categories',
        'No targets, flexible working',
        'Transparent tracking system'
      ],
      link: '/bank-partner'
    }
  ];

  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Business Consultancy Partnership
          </h2>
          <p className="text-lg text-gray-600">
            Join Digital Mitraa's consultancy network and grow your career with our partnership programs
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {partnerTypes.map((partner, index) => (
            <div 
              key={index}
              className={`rounded-xl overflow-hidden border ${partner.borderColor} transition-all hover:shadow-xl`}
            >
              <div className={`${partner.color} p-8`}>
                <div className="flex justify-between items-start">
                  <div>
                    {partner.icon}
                    <h3 className={`text-2xl font-bold mt-4 ${partner.textColor}`}>{partner.type}</h3>
                    <div className="font-medium text-gray-600 mt-1">{partner.fee}</div>
                  </div>
                  <div className="bg-white px-4 py-2 rounded-full text-sm font-medium text-gray-600 shadow-sm">
                    Partner Program
                  </div>
                </div>
                
                <div className="mt-8">
                  <h4 className="font-medium text-gray-800 mb-4">Benefits:</h4>
                  <ul className="space-y-3">
                    {partner.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-start">
                        <CheckCircle className="h-5 w-5 mr-2 mt-0.5 text-green-500" />
                        <span className="text-gray-700">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="mt-8">
                  <Link href={partner.link}>
                    <Button className={`w-full ${partner.buttonColor} text-white flex items-center justify-center`}>
                      Become a {partner.type}
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-indigo-900 rounded-xl p-8 text-white">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
            <div className="md:col-span-2">
              <h3 className="text-2xl font-bold mb-4">
                Become a Business Consultant Today
              </h3>
              <p className="text-indigo-100 mb-6">
                Join Digital Mitraa's consultancy network and help clients across multiple service categories. Whether as a franchisee or bank partner, you'll have all the tools to succeed as a consultant.
              </p>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-indigo-800/50 p-4 rounded-lg border border-indigo-700">
                  <div className="font-bold mb-2">Franchisee Consultants</div>
                  <p className="text-sm text-indigo-200">
                    Build your consultancy business with training, tools, and access to all service categories.
                  </p>
                </div>
                <div className="bg-indigo-800/50 p-4 rounded-lg border border-indigo-700">
                  <div className="font-bold mb-2">Bank Partner Consultants</div>
                  <p className="text-sm text-indigo-200">
                    Refer clients for all service categories with transparent commission tracking.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="text-center md:text-right">
              <Link href="/contact">
                <Button className="bg-white text-indigo-900 hover:bg-indigo-100 px-6 py-3 h-auto">
                  Contact Us For Details
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}