import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import { Link } from "wouter";

export function PricingSection() {
  const plans = [
    {
      name: "Starter",
      description: "Perfect for small businesses",
      price: 49,
      features: [
        "Basic SEO tools",
        "Social media integration",
        "5 AI marketing suggestions per month",
        "Basic analytics dashboard",
        "Email support"
      ],
      isPopular: false,
      cta: "Get Started"
    },
    {
      name: "Professional",
      description: "For growing businesses",
      price: 99,
      features: [
        "Advanced SEO tools",
        "Complete social media suite",
        "25 AI marketing suggestions per month",
        "Full analytics dashboard",
        "Priority email & chat support",
        "Content calendar"
      ],
      isPopular: true,
      cta: "Get Started"
    },
    {
      name: "Enterprise",
      description: "For large organizations",
      price: 249,
      features: [
        "All Professional features",
        "Unlimited AI marketing suggestions",
        "Custom reporting",
        "API access",
        "Dedicated account manager",
        "24/7 phone, email & chat support"
      ],
      isPopular: false,
      cta: "Contact Sales"
    }
  ];

  return (
    <div className="bg-gray-50 py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Simple, Transparent Pricing</h2>
          <p className="text-xl text-gray-500 max-w-3xl mx-auto">Choose the plan that's right for your business needs.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div 
              key={index} 
              className={`bg-white rounded-2xl shadow-md ${plan.isPopular ? 'border-2 border-primary-500' : 'border border-gray-100'} overflow-hidden relative`}
            >
              {plan.isPopular && (
                <div className="absolute top-0 inset-x-0 bg-primary-500 text-white text-center py-1 text-sm font-medium">
                  Most Popular
                </div>
              )}
              <div className={`p-8 ${plan.isPopular ? 'pt-12' : ''}`}>
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <p className="text-gray-500 mb-6">{plan.description}</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold">${plan.price}</span>
                  <span className="text-gray-500">/month</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center">
                      <Check className="text-green-500 mr-2" size={16} />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link href="/pricing">
                  <Button 
                    className={`w-full ${plan.isPopular ? 'bg-primary-600 hover:bg-primary-700 text-white' : 'bg-white text-primary-600 border border-primary-600 hover:bg-gray-50'}`}
                    variant={plan.isPopular ? "default" : "outline"}
                  >
                    {plan.cta}
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
