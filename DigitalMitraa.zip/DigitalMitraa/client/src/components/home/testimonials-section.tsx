import { Star } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export function TestimonialsSection() {
  const testimonials = [
    {
      text: "Digital Mitraa transformed our online presence. Our website traffic increased by 150% in just three months, and our conversion rates have never been better.",
      name: "Sarah Johnson",
      title: "CEO, TechStart",
      initial: "SJ"
    },
    {
      text: "The AI marketing assistant is like having a full-time marketing expert on staff. It's helped us create campaigns that really connect with our audience.",
      name: "Michael Chen",
      title: "Marketing Director, GrowthMax",
      initial: "MC"
    },
    {
      text: "The analytics dashboard has been a game-changer for us. We can now make data-driven decisions that have improved our ROI by over 80%.",
      name: "Priya Patel",
      title: "Founder, EcommerceElite",
      initial: "PP"
    }
  ];

  return (
    <div className="py-16 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">What Our Clients Say</h2>
          <p className="text-xl text-gray-500 max-w-3xl mx-auto">Hear from businesses that have transformed their digital presence with Digital Mitraa.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-8 rounded-xl shadow-md border border-gray-100">
              <div className="flex items-center mb-4">
                <div className="text-yellow-400 flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="fill-current" size={16} />
                  ))}
                </div>
              </div>
              <p className="text-gray-600 mb-6">{testimonial.text}</p>
              <div className="flex items-center">
                <Avatar className="h-12 w-12 mr-4">
                  <AvatarFallback className="bg-gray-200">{testimonial.initial}</AvatarFallback>
                </Avatar>
                <div>
                  <h4 className="font-semibold">{testimonial.name}</h4>
                  <p className="text-gray-500 text-sm">{testimonial.title}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
