import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Phone } from 'lucide-react';

export function CTASection() {
  return (
    <section className="py-16 md:py-24 bg-indigo-900 text-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6 leading-tight">
              Connect with Business Consultancy Experts
            </h2>
            <p className="text-xl text-indigo-100 mb-8">
              Digital Mitraa offers expert consultancy across five key service categories to help your business grow and succeed.
            </p>

            <ul className="space-y-4 mb-8">
              {[
                'Expert consultants for all business needs',
                'Specialized in Legal, Digital, Loans, Insurance & Real Estate',
                'Nationwide consultant network',
                'Transparent pricing with customized solutions',
                'Government-approved service delivery',
              ].map((item, index) => (
                <li key={index} className="flex items-start">
                  <CheckCircle className="h-6 w-6 mr-3 text-indigo-300 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/auth" className="inline-block">
                <Button className="bg-white text-indigo-900 hover:bg-indigo-50 flex items-center justify-center px-6 py-3 h-auto">
                  Get Started Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              
              <a 
                href="tel:+919876543210" 
                className="inline-flex items-center justify-center bg-transparent border border-white text-white hover:bg-white/10 rounded-md px-6 py-3"
              >
                <Phone className="mr-2 h-5 w-5" />
                Call Us: +91 9876543210
              </a>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-indigo-800">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold mb-2">Trusted Business Partner</h3>
              <p className="text-indigo-200">
                Join thousands of businesses who trust Digital Mitraa for their business needs
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-indigo-800/50 p-4 rounded-lg text-center">
                <div className="text-3xl font-bold">30+</div>
                <div className="text-indigo-200">Franchise Branches</div>
              </div>
              <div className="bg-indigo-800/50 p-4 rounded-lg text-center">
                <div className="text-3xl font-bold">300+</div>
                <div className="text-indigo-200">Bank Tie-ups</div>
              </div>
              <div className="bg-indigo-800/50 p-4 rounded-lg text-center">
                <div className="text-3xl font-bold">1L+</div>
                <div className="text-indigo-200">Clients Served</div>
              </div>
              <div className="bg-indigo-800/50 p-4 rounded-lg text-center">
                <div className="text-3xl font-bold">99%</div>
                <div className="text-indigo-200">Success Rate</div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-indigo-800 to-blue-800 p-6 rounded-lg">
              <div className="flex items-start mb-4">
                <div className="bg-white/20 p-2 rounded mr-4">
                  <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm0-2a8 8 0 100-16 8 8 0 000 16zm-5-8h2v2H7v-2zm5-6a1 1 0 011 1v3h3a1 1 0 010 2h-3v3a1 1 0 01-2 0v-3H8a1 1 0 010-2h3V7a1 1 0 011-1z" />
                  </svg>
                </div>
                <div>
                  <h4 className="font-bold text-lg">Special Offer</h4>
                  <p className="text-indigo-100 text-sm">
                    Sign up today and get 15% off on your first service booking
                  </p>
                </div>
              </div>
              <Link href="/auth" className="inline-block w-full">
                <Button className="w-full bg-white text-indigo-900 hover:bg-indigo-50">
                  Claim Offer
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}