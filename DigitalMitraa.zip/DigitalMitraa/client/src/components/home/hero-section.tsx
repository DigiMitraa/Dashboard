import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { CheckCircle, ArrowRight, PlayCircle } from 'lucide-react';

export function HeroSection() {
  return (
    <section className="py-12 md:py-20 bg-gradient-to-br from-indigo-900 via-indigo-800 to-blue-900 text-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-block mb-4 py-1 px-3 bg-indigo-700 bg-opacity-40 rounded-full backdrop-blur">
              <span className="text-indigo-200 text-sm font-medium">
                #1 Business Consultancy Services
              </span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              Your Complete Business Consultancy Partner
            </h1>
            
            <p className="text-lg md:text-xl text-indigo-100 mb-8 max-w-xl">
              Digital Mitraa offers expert consultancy services across Legal, Digital, Loans, Insurance, and Real Estate sectors through our nationwide network of franchisees and bank partners.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              {[
                'Multi-service consultancy firm',
                'Nationwide franchisee network',
                'Bank partnership program',
                'Expert consultant services',
                'Government approved services',
                'Complete business solutions',
              ].map((feature, index) => (
                <div key={index} className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-2 text-indigo-300" />
                  <span className="text-indigo-100">{feature}</span>
                </div>
              ))}
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/auth">
                <Button className="bg-white text-indigo-900 hover:bg-indigo-50 flex items-center justify-center px-6 py-3 h-auto">
                  Get Started
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              
              <Link href="/services">
                <Button variant="outline" className="border-white text-white hover:bg-white/10 flex items-center justify-center px-6 py-3 h-auto">
                  Explore Services
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="relative">
            <div className="relative z-10 bg-white/10 backdrop-blur-sm rounded-xl overflow-hidden border border-white/20">
              {/* Stats Section */}
              <div className="grid grid-cols-2 divide-x divide-white/10">
                <div className="p-6 text-center">
                  <div className="text-4xl font-bold mb-2">5000+</div>
                  <div className="text-indigo-200">Happy Clients</div>
                </div>
                <div className="p-6 text-center">
                  <div className="text-4xl font-bold mb-2">30+</div>
                  <div className="text-indigo-200">Service Categories</div>
                </div>
              </div>
              <div className="border-t border-white/10"></div>
              
              {/* Feature Image */}
              <div className="p-6">
                <div className="bg-gradient-to-tr from-indigo-600/30 to-blue-500/30 rounded-lg p-6 border border-white/10">
                  <div className="mb-4">
                    <svg className="h-12 w-12 mx-auto" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                      <path d="M12 16V12" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                      <path d="M12 8H12.01" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold text-center mb-2">AI-Powered Assistant</h3>
                  <p className="text-indigo-100 text-center mb-6">
                    Get intelligent advice for all your business needs with our AI assistant
                  </p>
                  <Link href="/ai-assistant">
                    <Button variant="outline" className="w-full border-white/20 text-white bg-white/10 hover:bg-white/20">
                      Try Now
                    </Button>
                  </Link>
                </div>
              </div>
              
              {/* Testimonial */}
              <div className="border-t border-white/10 p-6">
                <div className="flex items-start">
                  <div className="bg-indigo-600 rounded-full h-10 w-10 flex items-center justify-center flex-shrink-0 mr-3">
                    <span className="font-bold">RS</span>
                  </div>
                  <div>
                    <p className="text-sm text-indigo-100 mb-2">
                      "Digital Mitraa helped me register my company and secure a business loan within just 2 weeks. Their service is exceptional!"
                    </p>
                    <div className="font-medium">Rajesh Sharma, Entrepreneur</div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Background decoration */}
            <div className="absolute top-1/2 -translate-y-1/2 -right-6 h-64 w-64 bg-indigo-500 rounded-full filter blur-3xl opacity-20"></div>
            <div className="absolute bottom-10 -left-6 h-40 w-40 bg-blue-400 rounded-full filter blur-3xl opacity-20"></div>
          </div>
        </div>
        
        {/* Partners or Trusts Section */}
        <div className="mt-16 md:mt-24 text-center">
          <div className="text-sm text-indigo-300 uppercase tracking-wider mb-6">
            Trusted by businesses across India
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center justify-items-center">
            {['HDFC Bank', 'ICICI Bank', 'State Bank of India', 'Bank of Baroda'].map((partner, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-sm rounded-lg px-6 py-3 w-full">
                <div className="font-bold text-lg">{partner}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}