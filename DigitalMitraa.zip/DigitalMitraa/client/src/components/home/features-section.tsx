import { Search, Bot, BarChart2, Share2, Mail, CheckSquare } from "lucide-react";

export function FeaturesSection() {
  const features = [
    {
      title: "Advanced SEO Tools",
      description: "Optimize your website for search engines with our comprehensive SEO toolkit.",
      icon: Search,
      iconBgClass: "bg-primary-100 text-primary-600"
    },
    {
      title: "AI Marketing Assistant",
      description: "Let our AI help you craft perfect marketing campaigns and content strategies.",
      icon: Bot,
      iconBgClass: "bg-secondary-100 text-secondary-600"
    },
    {
      title: "Performance Analytics",
      description: "Track and visualize your marketing performance with detailed analytics.",
      icon: BarChart2,
      iconBgClass: "bg-purple-100 text-purple-600"
    },
    {
      title: "Social Media Management",
      description: "Manage all your social media platforms from a single, unified dashboard.",
      icon: Share2,
      iconBgClass: "bg-pink-100 text-pink-600"
    },
    {
      title: "Email Marketing",
      description: "Create, automate, and analyze email campaigns that convert subscribers into customers.",
      icon: Mail,
      iconBgClass: "bg-green-100 text-green-600"
    },
    {
      title: "Project Management",
      description: "Stay organized with our built-in marketing project management tools.",
      icon: CheckSquare,
      iconBgClass: "bg-yellow-100 text-yellow-600"
    }
  ];

  return (
    <div className="py-16 md:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Powerful Features for Digital Growth</h2>
          <p className="text-xl text-gray-500 max-w-3xl mx-auto">Everything you need to manage your online presence, grow your audience, and increase revenue.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="feature-card bg-white p-8 rounded-xl shadow-md border border-gray-100 transition duration-300 hover:-translate-y-1 hover:shadow-xl">
              <div className={`w-14 h-14 rounded-full ${feature.iconBgClass} flex items-center justify-center mb-6`}>
                <feature.icon size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-gray-500">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
