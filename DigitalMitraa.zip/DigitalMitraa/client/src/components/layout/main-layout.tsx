import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import React, { ReactNode, useState } from "react";
import { Menu, X, Phone, Mail, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";

type MainLayoutProps = {
  children: ReactNode;
};

export function MainLayout({ children }: MainLayoutProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top contact bar */}
      <div className="bg-indigo-900 text-white text-sm py-2 hidden md:block">
        <div className="container mx-auto px-4 flex justify-between">
          <div className="flex items-center space-x-4">
            <a href="tel:+919876543210" className="flex items-center hover:text-indigo-200">
              <Phone className="h-4 w-4 mr-1" />
              <span>+91 9876543210</span>
            </a>
            <a href="mailto:info@digitalmitraa.co.in" className="flex items-center hover:text-indigo-200">
              <Mail className="h-4 w-4 mr-1" />
              <span>info@digitalmitraa.co.in</span>
            </a>
          </div>
          <div className="flex items-center space-x-3">
            <a href="#" className="hover:text-indigo-200">
              <Facebook className="h-4 w-4" />
            </a>
            <a href="#" className="hover:text-indigo-200">
              <Twitter className="h-4 w-4" />
            </a>
            <a href="#" className="hover:text-indigo-200">
              <Instagram className="h-4 w-4" />
            </a>
            <a href="#" className="hover:text-indigo-200">
              <Linkedin className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>

      {/* Main navigation */}
      <header className="bg-white shadow-sm py-4 sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <nav className="flex justify-between items-center">
            <Link href="/">
              <a className="flex items-center">
                <span className="text-2xl font-bold text-indigo-800">Digital Mitraa</span>
              </a>
            </Link>

            {/* Desktop navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <Link href="/">
                <a className="text-gray-700 hover:text-indigo-700 font-medium">Home</a>
              </Link>
              <Link href="/services">
                <a className="text-gray-700 hover:text-indigo-700 font-medium">Services</a>
              </Link>
              <Link href="/pricing">
                <a className="text-gray-700 hover:text-indigo-700 font-medium">Pricing</a>
              </Link>
              <Link href="/blog">
                <a className="text-gray-700 hover:text-indigo-700 font-medium">Blog</a>
              </Link>
              <Link href="/contact">
                <a className="text-gray-700 hover:text-indigo-700 font-medium">Contact</a>
              </Link>
              <Link href="/auth">
                <Button className="bg-indigo-600 hover:bg-indigo-700">Login / Register</Button>
              </Link>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={toggleMobileMenu}
              className="md:hidden text-gray-700 focus:outline-none"
            >
              {isMobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </nav>

          {/* Mobile navigation */}
          {isMobileMenuOpen && (
            <div className="md:hidden mt-4 pb-4 space-y-4">
              <Link href="/">
                <a className="block text-gray-700 hover:text-indigo-700 font-medium">
                  Home
                </a>
              </Link>
              <Link href="/services">
                <a className="block text-gray-700 hover:text-indigo-700 font-medium">
                  Services
                </a>
              </Link>
              <Link href="/pricing">
                <a className="block text-gray-700 hover:text-indigo-700 font-medium">
                  Pricing
                </a>
              </Link>
              <Link href="/blog">
                <a className="block text-gray-700 hover:text-indigo-700 font-medium">
                  Blog
                </a>
              </Link>
              <Link href="/contact">
                <a className="block text-gray-700 hover:text-indigo-700 font-medium">
                  Contact
                </a>
              </Link>
              <Link href="/auth">
                <Button className="w-full bg-indigo-600 hover:bg-indigo-700">
                  Login / Register
                </Button>
              </Link>
            </div>
          )}
        </div>
      </header>

      {/* Main content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white pt-12 pb-6">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company info */}
            <div>
              <h3 className="text-xl font-bold mb-4">Digital Mitraa</h3>
              <p className="text-gray-400 mb-4">
                India's Most Trusted Business Service Provider for legal, digital, loan, and insurance services.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-white">
                  <Facebook className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  <Twitter className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  <Instagram className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  <Linkedin className="h-5 w-5" />
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="text-xl font-bold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/services">
                    <a className="text-gray-400 hover:text-white">Services</a>
                  </Link>
                </li>
                <li>
                  <Link href="/pricing">
                    <a className="text-gray-400 hover:text-white">Pricing</a>
                  </Link>
                </li>
                <li>
                  <Link href="/blog">
                    <a className="text-gray-400 hover:text-white">Blog</a>
                  </Link>
                </li>
                <li>
                  <Link href="/contact">
                    <a className="text-gray-400 hover:text-white">Contact</a>
                  </Link>
                </li>
              </ul>
            </div>

            {/* Partner Programs */}
            <div>
              <h3 className="text-xl font-bold mb-4">Partner Programs</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/franchisee">
                    <a className="text-gray-400 hover:text-white">Become a Franchisee</a>
                  </Link>
                </li>
                <li>
                  <Link href="/bank-partner">
                    <a className="text-gray-400 hover:text-white">Bank Partner Program</a>
                  </Link>
                </li>
                <li>
                  <Link href="/dashboard">
                    <a className="text-gray-400 hover:text-white">Partner Dashboard</a>
                  </Link>
                </li>
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h3 className="text-xl font-bold mb-4">Contact Us</h3>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-start">
                  <Phone className="h-5 w-5 mr-2 mt-0.5" />
                  <span>+91 9876543210</span>
                </li>
                <li className="flex items-start">
                  <Mail className="h-5 w-5 mr-2 mt-0.5" />
                  <span>info@digitalmitraa.co.in</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-6">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-gray-400 text-sm">
                &copy; {new Date().getFullYear()} Digital Mitraa. All rights reserved.
              </p>
              <div className="flex space-x-4 mt-4 md:mt-0">
                <Link href="/privacy-policy">
                  <a className="text-gray-400 hover:text-white text-sm">Privacy Policy</a>
                </Link>
                <Link href="/terms">
                  <a className="text-gray-400 hover:text-white text-sm">Terms & Conditions</a>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}