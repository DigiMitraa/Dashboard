import { Link, useLocation } from "wouter";
import { Logo } from "@/components/ui/logo";
import { useAuth } from "@/hooks/use-auth";
import { 
  Home, 
  Users, 
  Bot, 
  GitBranch, 
  BarChart2, 
  FileText, 
  Settings 
} from "lucide-react";

export function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const navItems = [
    { name: "Dashboard", icon: Home, href: "/dashboard" },
    { name: "User Management", icon: Users, href: "/dashboard/users" },
    { name: "AI Chatbot", icon: Bot, href: "/dashboard/ai-assistant" },
    { name: "Projects", icon: GitBranch, href: "/dashboard/projects" },
    { name: "Analytics", icon: BarChart2, href: "/dashboard/analytics" },
    { name: "Invoicing", icon: FileText, href: "/dashboard/invoicing" },
    { name: "Settings", icon: Settings, href: "/dashboard/settings" },
  ];

  return (
    <div className="w-64 flex flex-col bg-gray-800 h-full">
      <div className="flex items-center justify-center h-16 bg-gray-900">
        <Logo color="white" />
      </div>
      <div className="flex-1 flex flex-col overflow-y-auto">
        <nav className="flex-1 px-2 py-4 space-y-1">
          {navItems.map((item) => {
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href}>
                <a
                  className={`${
                    isActive
                      ? "bg-gray-900 text-white"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white"
                  } group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                >
                  <item.icon className="w-6 h-6 mr-3 text-gray-300" />
                  {item.name}
                </a>
              </Link>
            );
          })}
        </nav>
      </div>
      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-gray-500 mr-3 flex items-center justify-center">
            {user?.fullName.charAt(0)}
          </div>
          <div>
            <p className="text-sm font-medium text-white">{user?.fullName || "User"}</p>
            <p className="text-xs text-gray-400">{user?.role === "admin" ? "Admin" : "User"}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
