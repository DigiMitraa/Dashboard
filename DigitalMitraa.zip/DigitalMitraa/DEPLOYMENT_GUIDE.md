# Digital Mitraa - Deployment Guide

This guide will help you deploy the Digital Mitraa platform after you re-upload the project.

## Project Structure

- `client/`: Frontend React application
- `server/`: Backend Express API server
- `shared/`: Shared TypeScript schemas and types
- `public/`: Static assets

## Prerequisites

- Node.js v20+ and npm
- PostgreSQL database
- OpenAI API key

## Setup Steps

### 1. Install Dependencies

```bash
npm install
```

### 2. Database Setup

The project is configured to use a PostgreSQL database. You'll need to:

1. Create a PostgreSQL database
2. Set the following environment variables:
   - `DATABASE_URL`: Full connection URL
   - `PGHOST`: Database hostname
   - `PGUSER`: Database username
   - `PGPASSWORD`: Database password
   - `PGDATABASE`: Database name
   - `PGPORT`: Database port (typically 5432)

If using Replit, you can create a PostgreSQL database via the database section in the Replit interface.

### 3. Set Up Environment Variables

Create a `.env` file or set the following environment variables:

```
OPENAI_API_KEY=your_openai_api_key
SESSION_SECRET=a_secure_random_session_secret
```

### 4. Initialize the Database

Run the database migration to set up all tables:

```bash
npm run db:push
```

### 5. Development Mode

Start the application in development mode:

```bash
npm run dev
```

### 6. Production Deployment

For production deployment:

1. Build the frontend:
   ```bash
   npm run build
   ```

2. Start the production server:
   ```bash
   npm start
   ```

## Deployment Options

### Replit

1. Upload your project zip file to Replit
2. Set up the PostgreSQL database from the Replit interface
3. Set the required environment variables in the Secrets section
4. Run the application using the "Start application" workflow

### Custom Domain Setup

To use your custom domain (www.digitalmitraa.co.in):

1. Go to your domain registrar and point the DNS records to your hosting provider
2. Set up HTTPS certificates (Let's Encrypt is recommended)
3. Configure your server to serve the Digital Mitraa application

## Testing Credentials

For testing purposes, the following accounts are available:

- Admin: 
  - Username: Digital7890987
  - Password: Digital123@123

- Bank Partner:
  - Username: Bank123456
  - Password: Digital123@123

- Franchisee:
  - Username: Franchisee123
  - Password: Digital123@123

## Database Schema

The application uses the following main tables:

- `users`: User accounts with different roles
- `projects`: Client projects
- `messages`: AI assistant chat messages
- `services`: Available services
- `service_categories`: Categories of services

## Troubleshooting

- **Database Connection Issues**: Verify your database credentials and connection string
- **OpenAI API Issues**: Check your OpenAI API key and ensure it has sufficient credits
- **Session Issues**: Ensure the SESSION_SECRET environment variable is set properly

## Support

For issues or questions, please contact the Digital Mitraa support team.