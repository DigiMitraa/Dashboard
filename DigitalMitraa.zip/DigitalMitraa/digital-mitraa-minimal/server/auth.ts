import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express, Request, Response, NextFunction } from "express";
import session from "express-session";
import { storage } from "./storage";
import { User, InsertUser } from "@shared/schema";

// Define custom interfaces for type safety
interface AuthInfo {
  message?: string;
}

// Define the User interface for Express session
declare global {
  namespace Express {
    interface User {
      id: number;
      username: string;
      password: string;
      email: string;
      fullName: string;
      role: string; // "admin", "franchisee", "bank_partner", "user"
      isActive: boolean;
      isApproved: boolean;
      subscriptionStatus: string | null;
      subscriptionExpiry: Date | null;
      franchiseeId: number | null;
      createdAt: Date | null;
    }
  }
}

export function setupAuth(app: Express) {
  // Configure session
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET!,
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: { 
      maxAge: 1000 * 60 * 60 * 24, // 1 day
      secure: process.env.NODE_ENV === "production"
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure passport with LocalStrategy
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        // Using the validateCredentials method from storage
        const user = await storage.validateCredentials(username, password);
        
        if (!user) {
          return done(null, false, { message: "Invalid username or password" });
        }
        
        // Check if user is active
        if (!user.isActive) {
          return done(null, false, { message: "Account is disabled" });
        }
        
        // Check if user is approved (except for admin who is always approved)
        if (!user.isApproved && user.role !== "admin") {
          return done(null, false, { message: "Account is pending approval" });
        }
        
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }),
  );

  // Serialize/deserialize user for session
  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      if (!user) {
        return done(null, false);
      }
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Register endpoint with role-specific handling
  app.post("/api/register", async (req, res, next) => {
    try {
      // Check if username or email already exists
      const existingUsername = await storage.getUserByUsername(req.body.username);
      if (existingUsername) {
        return res.status(400).json({ error: "Username already exists" });
      }
      
      const existingEmail = await storage.getUserByEmail(req.body.email);
      if (existingEmail) {
        return res.status(400).json({ error: "Email already exists" });
      }

      // Validate role
      const validRoles = ["admin", "franchisee", "bank_partner", "user"];
      const role = req.body.role || "user";
      
      if (!validRoles.includes(role)) {
        return res.status(400).json({ error: "Invalid role" });
      }
      
      // Create the user
      const user = await storage.createUser({
        ...req.body,
        role: role,
        // Only admins are auto-approved, others require approval
        isActive: true,
        isApproved: role === "admin", 
        subscriptionStatus: null,
        subscriptionExpiry: null,
        franchiseeId: req.body.franchiseeId || null
      });

      // Login the user
      req.login(user, (err) => {
        if (err) return next(err);
        
        // Remove password from response
        const { password, ...userWithoutPassword } = user;
        res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ error: "Error during registration" });
    }
  });

  // Login endpoint
  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: User | false, info: { message: string } | undefined) => {
      if (err) return next(err);
      
      if (!user) {
        return res.status(401).json({ error: info?.message || "Authentication failed" });
      }
      
      req.login(user, (loginErr: any) => {
        if (loginErr) return next(loginErr);
        
        // Remove password from response
        const { password, ...userWithoutPassword } = user as User;
        res.status(200).json(userWithoutPassword);
      });
    })(req, res, next);
  });

  // Logout endpoint
  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  // User info endpoint
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ error: "Not authenticated" });
    
    // Remove password from response
    const { password, ...userWithoutPassword } = req.user;
    res.json(userWithoutPassword);
  });
  
  // Admin-only endpoint to get all users
  app.get("/api/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      // Remove passwords from response
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.json(usersWithoutPasswords);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ error: "Error fetching users" });
    }
  });
  
  // Endpoint to approve users (admin only)
  app.post("/api/users/:id/approve", isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(userId, { isApproved: true });
      
      // Remove password from response
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error approving user:", error);
      res.status(500).json({ error: "Error approving user" });
    }
  });
}

// Middleware for role-based access control
export function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ error: "Authentication required" });
}

export function isAdmin(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated() && req.user.role === "admin") {
    return next();
  }
  res.status(403).json({ error: "Admin access required" });
}

export function isFranchisee(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated() && req.user.role === "franchisee") {
    return next();
  }
  res.status(403).json({ error: "Franchisee access required" });
}

export function isBankPartner(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated() && req.user.role === "bank_partner") {
    return next();
  }
  res.status(403).json({ error: "Bank partner access required" });
}

export function isApproved(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated() && req.user.isApproved) {
    return next();
  }
  res.status(403).json({ error: "Your account is pending approval" });
}

export function isActive(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated() && req.user.isActive) {
    return next();
  }
  res.status(403).json({ error: "Your account is inactive" });
}