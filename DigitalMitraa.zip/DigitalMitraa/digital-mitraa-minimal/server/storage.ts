import { 
  users, projects, invoices, blogs, activities, messages, 
  serviceCategories, services, leads, commissions, subscriptions, 
  coupons, wallets, walletTransactions, bankAccounts, paymentTransactions,
  type User, type InsertUser, 
  type Project, type InsertProject,
  type Invoice, type InsertInvoice,
  type Blog, type InsertBlog,
  type Activity, type InsertActivity,
  type Message, type InsertMessage,
  type ServiceCategory, type InsertServiceCategory,
  type Service, type InsertService,
  type Lead, type InsertLead,
  type Commission, type InsertCommission,
  type Subscription, type InsertSubscription,
  type Coupon, type InsertCoupon,
  type Wallet, type InsertWallet,
  type WalletTransaction, type InsertWalletTransaction,
  type BankAccount, type InsertBankAccount,
  type PaymentTransaction, type InsertPaymentTransaction
} from "@shared/schema";
import { drizzle } from "drizzle-orm/postgres-js";
import { eq, and, asc } from "drizzle-orm";
import postgres from "postgres";
import connectPg from "connect-pg-simple";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import createMemoryStore from "memorystore";

// Hash password functions
const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Interface to define storage methods
export interface IStorage {
  // Session store
  sessionStore: session.Store;
  
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  getUsersByRole(role: string): Promise<User[]>;
  getUsersByFranchisee(franchiseeId: number): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User>;
  deleteUser(id: number): Promise<void>;
  validateCredentials(username: string, password: string): Promise<User | null>;
  
  // Project methods
  getProject(id: number): Promise<Project | undefined>;
  getAllProjects(): Promise<Project[]>;
  getProjectsByUserId(userId: number): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project>;
  deleteProject(id: number): Promise<void>;
  
  // Message methods for AI Assistant
  getMessage(id: number): Promise<Message | undefined>;
  getMessagesByUserId(userId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  deleteAllMessagesByUserId(userId: number): Promise<void>;
}

// PostgreSQL implementation
export class PostgresStorage implements IStorage {
  sessionStore: session.Store;
  private db: ReturnType<typeof drizzle>;
  private client: ReturnType<typeof postgres>;
  
  constructor() {
    const connectionString = process.env.DATABASE_URL;
    if (!connectionString) {
      throw new Error("DATABASE_URL is not defined");
    }
    
    this.client = postgres(connectionString, { max: 1 });
    this.db = drizzle(this.client);
    
    // Connect PG Simple for session store
    const PostgresStore = connectPg(session);
    this.sessionStore = new PostgresStore({
      conObject: {
        connectionString,
        ssl: process.env.NODE_ENV === "production",
      },
      createTableIfMissing: true,
    });
    
    // Initialize database
    this.initializeDatabase().catch(console.error);
  }
  
  private async initializeDatabase() {
    // Check if admin user exists, if not create it
    const adminUser = await this.getUserByUsername("Digital7890987");
    if (!adminUser) {
      console.log("Creating initial admin user...");
      await this.seedInitialData();
    }
  }
  
  async seedInitialData() {
    // Hash the admin password
    const hashedAdminPassword = await hashPassword("Digital123@123");
    
    // Create admin user
    try {
      const admin = await this.createUser({
        username: "Digital7890987",
        password: hashedAdminPassword,
        email: "admin@digitalmitraa.co.in",
        fullName: "Digital Mitraa Admin",
        role: "admin",
        isActive: true,
        isApproved: true,
        subscriptionStatus: null,
        subscriptionExpiry: null,
        franchiseeId: null
      });
      
      console.log("Admin user created:", admin.username);
      
      // Create a franchisee user
      const franchiseePassword = await hashPassword("password123");
      const franchisee = await this.createUser({
        username: "franchisee1",
        password: franchiseePassword,
        email: "franchisee1@digitalmitraa.co.in",
        fullName: "Franchisee User 1",
        role: "franchisee",
        isActive: true,
        isApproved: true,
        subscriptionStatus: "active",
        subscriptionExpiry: new Date(2025, 11, 31),
        franchiseeId: null,
      });
      
      console.log("Franchisee user created:", franchisee.username);
      
      // Create a bank partner
      const bankPassword = await hashPassword("password123");
      const bankPartner = await this.createUser({
        username: "bankpartner",
        password: bankPassword,
        email: "bank@digitalmitraa.co.in",
        fullName: "Bank Partner",
        role: "bank_partner",
        isActive: true,
        isApproved: true,
        subscriptionStatus: null,
        subscriptionExpiry: null,
        franchiseeId: null,
      });
      
      console.log("Bank partner created:", bankPartner.username);
    } catch (error) {
      console.error("Error seeding initial data:", error);
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async getAllUsers(): Promise<User[]> {
    return await this.db.select().from(users);
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return await this.db.select().from(users).where(eq(users.role, role));
  }

  async getUsersByFranchisee(franchiseeId: number): Promise<User[]> {
    return await this.db.select().from(users).where(eq(users.franchiseeId, franchiseeId));
  }

  async createUser(user: InsertUser): Promise<User> {
    // If password isn't already hashed, hash it
    let finalPassword = user.password;
    if (!finalPassword.includes('.')) {
      finalPassword = await hashPassword(user.password);
    }
    
    const userData = { ...user, password: finalPassword };
    
    try {
      const result = await this.db.insert(users).values(userData).returning();
      return result[0];
    } catch (error: any) {
      console.error('Error creating user:', error);
      throw new Error(`Failed to create user: ${error.message}`);
    }
  }

  async updateUser(id: number, user: Partial<InsertUser>): Promise<User> {
    // If password is provided, hash it before storing
    if (user.password) {
      user.password = await hashPassword(user.password);
    }
    
    try {
      const result = await this.db.update(users)
        .set(user)
        .where(eq(users.id, id))
        .returning();
        
      if (result.length === 0) {
        throw new Error(`User with id ${id} not found`);
      }
      
      return result[0];
    } catch (error: any) {
      console.error('Error updating user:', error);
      throw new Error(`Failed to update user: ${error.message}`);
    }
  }

  async deleteUser(id: number): Promise<void> {
    await this.db.delete(users).where(eq(users.id, id));
  }
  
  async validateCredentials(username: string, password: string): Promise<User | null> {
    try {
      const user = await this.getUserByUsername(username);
      if (!user) return null;
      
      const isPasswordValid = await comparePasswords(password, user.password);
      return isPasswordValid ? user : null;
    } catch (error) {
      console.error('Error validating credentials:', error);
      return null;
    }
  }

  // Project methods
  async getProject(id: number): Promise<Project | undefined> {
    const result = await this.db.select().from(projects).where(eq(projects.id, id));
    return result[0];
  }

  async getAllProjects(): Promise<Project[]> {
    return await this.db.select().from(projects);
  }

  async getProjectsByUserId(userId: number): Promise<Project[]> {
    return await this.db.select().from(projects).where(eq(projects.userId, userId));
  }

  async createProject(project: InsertProject): Promise<Project> {
    try {
      const result = await this.db.insert(projects).values(project).returning();
      return result[0];
    } catch (error: any) {
      console.error('Error creating project:', error);
      throw new Error(`Failed to create project: ${error.message}`);
    }
  }

  async updateProject(id: number, project: Partial<InsertProject>): Promise<Project> {
    try {
      const result = await this.db.update(projects)
        .set(project)
        .where(eq(projects.id, id))
        .returning();
        
      if (result.length === 0) {
        throw new Error(`Project with id ${id} not found`);
      }
      
      return result[0];
    } catch (error: any) {
      console.error('Error updating project:', error);
      throw new Error(`Failed to update project: ${error.message}`);
    }
  }

  async deleteProject(id: number): Promise<void> {
    await this.db.delete(projects).where(eq(projects.id, id));
  }
  
  // Message methods
  async getMessage(id: number): Promise<Message | undefined> {
    const result = await this.db.select().from(messages).where(eq(messages.id, id));
    return result[0];
  }

  async getMessagesByUserId(userId: number): Promise<Message[]> {
    return await this.db.select()
      .from(messages)
      .where(eq(messages.userId, userId))
      .orderBy(asc(messages.createdAt));
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    try {
      const result = await this.db.insert(messages).values(message).returning();
      return result[0];
    } catch (error: any) {
      console.error('Error creating message:', error);
      throw new Error(`Failed to create message: ${error.message}`);
    }
  }

  async deleteAllMessagesByUserId(userId: number): Promise<void> {
    await this.db.delete(messages).where(eq(messages.userId, userId));
  }
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  sessionStore: session.Store;
  
  private userMap: Map<number, User> = new Map();
  private projectMap: Map<number, Project> = new Map();
  private invoiceMap: Map<number, Invoice> = new Map();
  private blogMap: Map<number, Blog> = new Map();
  private activityMap: Map<number, Activity> = new Map();
  private messageMap: Map<number, Message> = new Map();
  private serviceCategoryMap: Map<number, ServiceCategory> = new Map();
  private serviceMap: Map<number, Service> = new Map();
  private leadMap: Map<number, Lead> = new Map();
  private commissionMap: Map<number, Commission> = new Map();
  private subscriptionMap: Map<number, Subscription> = new Map();
  private couponMap: Map<number, Coupon> = new Map();
  private walletMap: Map<number, Wallet> = new Map();
  private walletTransactionMap: Map<number, WalletTransaction> = new Map();
  private bankAccountMap: Map<number, BankAccount> = new Map();
  private paymentTransactionMap: Map<number, PaymentTransaction> = new Map();
  
  private userCurrentId = 1;
  private projectCurrentId = 1;
  private invoiceCurrentId = 1;
  private blogCurrentId = 1;
  private activityCurrentId = 1;
  private messageCurrentId = 1;
  private serviceCategoryCurrentId = 1;
  private serviceCurrentId = 1;
  private leadCurrentId = 1;
  private commissionCurrentId = 1;
  private subscriptionCurrentId = 1;
  private couponCurrentId = 1;
  private walletCurrentId = 1;
  private walletTransactionCurrentId = 1;
  private bankAccountCurrentId = 1;
  private paymentTransactionCurrentId = 1;

  constructor() {
    // Initialize session store
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Prune expired entries every 24h
    });
    
    // Create initial admin
    this.seedInitialData().catch(console.error);
  }

  async seedInitialData() {
    // Check if admin exists
    const adminUser = await this.getUserByUsername("Digital7890987");
    if (!adminUser) {
      // Create admin user
      const adminPassword = await hashPassword("Digital123@123");
      
      await this.createUser({
        username: "Digital7890987",
        password: adminPassword,
        email: "admin@digitalmitraa.co.in",
        fullName: "Digital Mitraa Admin",
        role: "admin",
        isActive: true,
        isApproved: true,
        subscriptionStatus: null,
        subscriptionExpiry: null,
        franchiseeId: null
      });
      
      // Create a franchisee user
      const franchiseePassword = await hashPassword("password123");
      const franchisee = await this.createUser({
        username: "franchisee1",
        password: franchiseePassword,
        email: "franchisee1@digitalmitraa.co.in", 
        fullName: "Franchisee User 1",
        role: "franchisee",
        isActive: true,
        isApproved: true,
        subscriptionStatus: "active",
        subscriptionExpiry: new Date(2025, 11, 31),
        franchiseeId: null,
      });
      
      // Create a bank partner
      const bankPassword = await hashPassword("password123");
      await this.createUser({
        username: "bankpartner",
        password: bankPassword,
        email: "bank@digitalmitraa.co.in",
        fullName: "Bank Partner",
        role: "bank_partner",
        isActive: true,
        isApproved: true,
        subscriptionStatus: null,
        subscriptionExpiry: null,
        franchiseeId: null,
      });
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.userMap.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.userMap.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.userMap.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.userMap.values());
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return Array.from(this.userMap.values()).filter(
      (user) => user.role === role
    );
  }

  async getUsersByFranchisee(franchiseeId: number): Promise<User[]> {
    return Array.from(this.userMap.values()).filter(
      (user) => user.franchiseeId === franchiseeId
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const now = new Date();
    
    // Create a properly typed User object
    const newUser: User = {
      id,
      username: user.username,
      password: user.password,
      email: user.email,
      fullName: user.fullName,
      role: user.role || "user",
      isActive: user.isActive ?? true,
      isApproved: user.isApproved ?? false,
      subscriptionStatus: user.subscriptionStatus || null,
      subscriptionExpiry: user.subscriptionExpiry || null,
      franchiseeId: user.franchiseeId || null,
      createdAt: now
    };
    
    this.userMap.set(id, newUser);
    return newUser;
  }

  async updateUser(id: number, user: Partial<InsertUser>): Promise<User> {
    const existingUser = await this.getUser(id);
    if (!existingUser) {
      throw new Error(`User with ID ${id} not found`);
    }
    
    const updatedUser: User = {
      ...existingUser,
      ...user,
    };
    
    this.userMap.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<void> {
    this.userMap.delete(id);
  }
  
  async validateCredentials(username: string, password: string): Promise<User | null> {
    try {
      const user = await this.getUserByUsername(username);
      if (!user) return null;
      
      const isPasswordValid = await comparePasswords(password, user.password);
      return isPasswordValid ? user : null;
    } catch (error) {
      console.error('Error validating credentials:', error);
      return null;
    }
  }

  async getProject(id: number): Promise<Project | undefined> {
    return this.projectMap.get(id);
  }

  async getAllProjects(): Promise<Project[]> {
    return Array.from(this.projectMap.values());
  }

  async getProjectsByUserId(userId: number): Promise<Project[]> {
    return Array.from(this.projectMap.values()).filter(
      (project) => project.userId === userId
    );
  }

  async createProject(project: InsertProject): Promise<Project> {
    const id = this.projectCurrentId++;
    const newProject: Project = {
      ...project,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
      status: project.status || "pending",
      progress: project.progress || 0
    };
    this.projectMap.set(id, newProject);
    return newProject;
  }

  async updateProject(id: number, project: Partial<InsertProject>): Promise<Project> {
    const existingProject = await this.getProject(id);
    if (!existingProject) {
      throw new Error(`Project with ID ${id} not found`);
    }
    
    const updatedProject: Project = {
      ...existingProject,
      ...project,
      updatedAt: new Date()
    };
    
    this.projectMap.set(id, updatedProject);
    return updatedProject;
  }

  async deleteProject(id: number): Promise<void> {
    this.projectMap.delete(id);
  }
  
  // Message methods
  async getMessage(id: number): Promise<Message | undefined> {
    return this.messageMap.get(id);
  }

  async getMessagesByUserId(userId: number): Promise<Message[]> {
    return Array.from(this.messageMap.values())
      .filter(message => message.userId === userId)
      .sort((a, b) => {
        if (!a.createdAt || !b.createdAt) return 0;
        return a.createdAt.getTime() - b.createdAt.getTime();
      });
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const id = this.messageCurrentId++;
    const now = new Date();
    
    const newMessage: Message = {
      id,
      content: message.content,
      role: message.role,
      userId: message.userId,
      createdAt: now
    };
    
    this.messageMap.set(id, newMessage);
    return newMessage;
  }

  async deleteAllMessagesByUserId(userId: number): Promise<void> {
    // Use Array.from to convert the map entries to an array
    Array.from(this.messageMap.entries()).forEach(([id, message]) => {
      if (message.userId === userId) {
        this.messageMap.delete(id);
      }
    });
  }
}

// Choose storage implementation based on environment
// If DATABASE_URL exists, use PostgreSQL, otherwise use in-memory
let storage: IStorage;

try {
  if (process.env.DATABASE_URL) {
    console.log('Using PostgreSQL storage');
    storage = new PostgresStorage();
  } else {
    console.log('Using in-memory storage');
    storage = new MemStorage();
  }
} catch (error) {
  console.error('Failed to initialize PostgreSQL storage, falling back to in-memory:', error);
  storage = new MemStorage();
}

export { storage };