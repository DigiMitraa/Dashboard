import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Define default system instructions for different AI capabilities
const SYSTEM_PROMPTS = {
  marketing: "You are a digital marketing expert and AI assistant for Digital Mitraa platform. Your expertise includes SEO, content marketing, social media strategy, email marketing, and digital marketing analytics. Provide helpful, concise, and practical advice.",
  legal: "You are a legal consultant for Digital Mitraa platform. Your expertise includes business law, contract review, intellectual property, regulatory compliance, and legal documentation. Provide helpful, accurate, and practical legal guidance while clearly stating you're not providing official legal advice.",
  financial: "You are a financial advisor for Digital Mitraa platform. Your expertise includes loan assessment, financial planning, investment advice, insurance evaluation, and banking services. Provide helpful financial guidance while clearly stating you're not providing official financial advice.",
  real_estate: "You are a real estate consultant for Digital Mitraa platform. Your expertise includes property valuation, market analysis, investment opportunities, regulatory requirements, and transaction guidance. Provide helpful real estate advice.",
  multiservice: "You are an expert consultant for Digital Mitraa platform specializing in multiple service domains including Legal, Digital, Loans, Insurance, and Real Estate. Provide comprehensive, accurate, and practical guidance across these domains."
};

// Fine-tuned model parameters for different domains
const MODEL_CONFIGURATIONS = {
  default: {
    model: "gpt-4o",
    temperature: 0.7,
    max_tokens: 1000,
  },
  precise: {
    model: "gpt-4o",
    temperature: 0.2,
    max_tokens: 1000,
  },
  creative: {
    model: "gpt-4o",
    temperature: 0.9,
    max_tokens: 1500,
  },
  balanced: {
    model: "gpt-4o",
    temperature: 0.5,
    max_tokens: 1200,
  }
};

/**
 * Selects appropriate model configuration based on the domain and task
 * @param domain The business domain for the AI response
 * @param task The specific task being performed
 * @returns The appropriate model configuration
 */
function selectModelConfiguration(domain: string, task: string): any {
  if (task === 'ideation' || task === 'creative-writing') {
    return MODEL_CONFIGURATIONS.creative;
  }
  
  if (domain === 'legal' || domain === 'financial' || task === 'analysis') {
    return MODEL_CONFIGURATIONS.precise;
  }
  
  if (domain === 'digital' || domain === 'marketing') {
    return MODEL_CONFIGURATIONS.balanced;
  }
  
  return MODEL_CONFIGURATIONS.default;
}

/**
 * Gets the appropriate system prompt based on domain
 * @param domain The business domain for which to get the system prompt
 * @returns The system prompt for the specified domain
 */
function getSystemPrompt(domain: string): string {
  switch (domain) {
    case 'marketing':
    case 'digital':
      return SYSTEM_PROMPTS.marketing;
    case 'legal':
      return SYSTEM_PROMPTS.legal;
    case 'financial':
    case 'loans':
    case 'insurance':
      return SYSTEM_PROMPTS.financial;
    case 'real_estate':
      return SYSTEM_PROMPTS.real_estate;
    default:
      return SYSTEM_PROMPTS.multiservice;
  }
}

/**
 * Sends a message to the OpenAI chat model and returns the response
 * @param prompt The message to send to the model
 * @param domain Optional domain to specialize the response (marketing, legal, financial, real_estate)
 * @param task Optional task type to optimize the model configuration
 * @param context Optional array of previous messages for context
 * @returns The AI generated response
 */
export async function getAIMarketingResponse(
  prompt: string, 
  domain: string = 'marketing',
  task: string = 'default',
  context: Array<{role: string, content: string}> = []
): Promise<string> {
  try {
    const systemPrompt = getSystemPrompt(domain);
    const modelConfig = selectModelConfiguration(domain, task);
    
    const messages = [
      {
        role: "system",
        content: systemPrompt
      },
      ...context,
      { role: "user", content: prompt }
    ];

    const response = await openai.chat.completions.create({
      model: modelConfig.model,
      messages: messages as any,
      temperature: modelConfig.temperature,
      max_tokens: modelConfig.max_tokens,
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("Error calling OpenAI:", error);
    return "I'm having trouble connecting to my knowledge base right now. Please try again in a moment.";
  }
}

/**
 * Generates content ideas based on a topic
 * @param topic The marketing topic to generate ideas for
 * @param count The number of ideas to generate
 * @param domain Optional domain to tailor ideas for specific industries
 * @returns JSON array of content ideas
 */
export async function generateContentIdeas(
  topic: string, 
  count: number = 5, 
  domain: string = 'marketing'
): Promise<{title: string, description: string}[]> {
  try {
    const prompt = `Generate ${count} creative content ideas related to "${topic}" for ${domain}. Each idea should have a catchy title and a brief description. Respond with JSON in this format: {"ideas": [{"title": "string", "description": "string"}]}`;
    
    const systemPrompt = getSystemPrompt(domain);
    const modelConfig = selectModelConfiguration(domain, 'ideation');
    
    const response = await openai.chat.completions.create({
      model: modelConfig.model,
      messages: [
        {
          role: "system",
          content: systemPrompt
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: modelConfig.temperature,
      max_tokens: modelConfig.max_tokens,
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.ideas || [];
  } catch (error) {
    console.error("Error generating content ideas:", error);
    return [];
  }
}

/**
 * Analyzes SEO performance and provides recommendations
 * @param url The URL or website to analyze
 * @param industry Optional industry context to tailor SEO recommendations
 * @returns JSON object with SEO analysis and recommendations
 */
export async function analyzeSEO(
  url: string,
  industry: string = 'general'
): Promise<{score: number, strengths: string[], weaknesses: string[], recommendations: string[]}> {
  try {
    const prompt = `Analyze the SEO potential for a website like "${url}" in the ${industry} industry. Provide a score from 1-10, list key strengths, weaknesses, and actionable recommendations. Respond with JSON in this format: {"score": number, "strengths": [string], "weaknesses": [string], "recommendations": [string]}`;
    
    // Use precise configuration for analysis
    const modelConfig = MODEL_CONFIGURATIONS.precise;
    
    const response = await openai.chat.completions.create({
      model: modelConfig.model,
      messages: [
        {
          role: "system",
          content: "You are an SEO expert who provides detailed and actionable SEO analysis. Your analysis should be data-driven, insightful, and provide concrete steps for improvement."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: modelConfig.temperature,
      max_tokens: modelConfig.max_tokens,
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      score: result.score || 5,
      strengths: result.strengths || [],
      weaknesses: result.weaknesses || [],
      recommendations: result.recommendations || []
    };
  } catch (error) {
    console.error("Error analyzing SEO:", error);
    return {
      score: 5,
      strengths: ["Could not analyze strengths"],
      weaknesses: ["Error processing request"],
      recommendations: ["Please try again later"]
    };
  }
}

/**
 * Generates marketing copy for different platforms
 * @param product The product or service to generate copy for
 * @param platform The platform (email, social, ad, etc.)
 * @param tone Optional tone for the copy (professional, conversational, humorous, etc.)
 * @param targetAudience Optional target audience to tailor the content
 * @returns Generated marketing copy
 */
export async function generateMarketingCopy(
  product: string, 
  platform: string,
  tone: string = 'professional',
  targetAudience: string = 'general'
): Promise<string> {
  try {
    const prompt = `Generate compelling marketing copy for "${product}" to be used on ${platform}. 
    Use a ${tone} tone and target ${targetAudience} audience. 
    Be persuasive, engaging, and tailored to the platform's typical format.`;
    
    // Use creative configuration for marketing copy
    const modelConfig = MODEL_CONFIGURATIONS.creative;
    
    const response = await openai.chat.completions.create({
      model: modelConfig.model,
      messages: [
        {
          role: "system",
          content: "You are a copywriting expert specializing in creating compelling marketing content. Your copy should be concise, persuasive, and tailored to the specific platform and audience."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: modelConfig.temperature,
      max_tokens: modelConfig.max_tokens
    });

    return response.choices[0].message.content || "Unable to generate marketing copy at this time.";
  } catch (error) {
    console.error("Error generating marketing copy:", error);
    return "Unable to generate marketing copy at this time.";
  }
}

/**
 * Generates a complete business document based on the specified type
 * @param documentType The type of document to generate (business plan, proposal, legal agreement, etc.)
 * @param details Specific details to include in the document
 * @param industry Optional industry to tailor the document for
 * @returns Generated document content
 */
export async function generateBusinessDocument(
  documentType: string,
  details: string,
  industry: string = 'general'
): Promise<string> {
  try {
    const prompt = `Generate a comprehensive ${documentType} for a business in the ${industry} industry with the following details: ${details}. 
    The document should be professional, well-structured, and include all relevant sections.`;
    
    // Use precise configuration for business documents
    const modelConfig = MODEL_CONFIGURATIONS.precise;
    
    const response = await openai.chat.completions.create({
      model: modelConfig.model,
      messages: [
        {
          role: "system",
          content: "You are a business documentation expert specializing in creating professional, comprehensive business documents. Your documents should be well-structured, detailed, and follow standard industry formats."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: modelConfig.temperature,
      max_tokens: modelConfig.max_tokens
    });

    return response.choices[0].message.content || "Unable to generate the document at this time.";
  } catch (error) {
    console.error("Error generating business document:", error);
    return "Unable to generate the document at this time.";
  }
}
