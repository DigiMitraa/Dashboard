import type { Express, Request as ExpressRequest, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { setupAuth, isAuthenticated, isAdmin, isFranchisee, isBankPartner, isApproved, isActive } from "./auth";
import { storage } from "./storage";
import { getAIMarketingResponse, generateContentIdeas, analyzeSEO, generateMarketingCopy, generateBusinessDocument } from "./openai";
import { insertUserSchema, insertProjectSchema, insertMessageSchema } from "@shared/schema";
import { z } from "zod";

// Extend the Request type with user property
interface Request extends ExpressRequest {
  user?: {
    id: number;
    username: string;
    password: string;
    email: string;
    fullName: string;
    role: string;
    isActive: boolean;
    isApproved: boolean;
    subscriptionStatus: string | null;
    subscriptionExpiry: Date | null;
    franchiseeId: number | null;
    createdAt: Date | null;
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // User routes
  app.get("/api/users", isAuthenticated, isAdmin, async (req, res) => {
    const users = await storage.getAllUsers();
    res.json(users);
  });

  app.get("/api/users/:id", isAuthenticated, async (req, res) => {
    const userId = parseInt(req.params.id);
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    
    // Only admins can view any user, others can only view themselves
    if (!req.user || (req.user.role !== "admin" && req.user.id !== user.id)) {
      return res.status(403).json({ error: "Unauthorized" });
    }
    
    res.json(user);
  });

  // Project routes
  app.get("/api/projects", isAuthenticated, async (req, res) => {
    let projects;
    
    // Admin can see all projects
    if (req.user && req.user.role === "admin") {
      projects = await storage.getAllProjects();
    } else {
      // Users can only see their own projects
      projects = await storage.getProjectsByUserId(req.user?.id || 0);
    }
    
    res.json(projects);
  });

  app.post("/api/projects", isAuthenticated, async (req, res) => {
    try {
      const projectData = insertProjectSchema.parse(req.body);
      
      // Set current user as the project owner
      const project = await storage.createProject({
        ...projectData,
        userId: req.user?.id || 0
      });
      
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create project" });
    }
  });

  app.get("/api/projects/:id", isAuthenticated, async (req, res) => {
    const projectId = parseInt(req.params.id);
    const project = await storage.getProject(projectId);
    
    if (!project) {
      return res.status(404).json({ error: "Project not found" });
    }
    
    // Only admins or the project owner can view the project
    if (!req.user || (req.user.role !== "admin" && req.user.id !== project.userId)) {
      return res.status(403).json({ error: "Unauthorized" });
    }
    
    res.json(project);
  });

  app.put("/api/projects/:id", isAuthenticated, async (req, res) => {
    const projectId = parseInt(req.params.id);
    const project = await storage.getProject(projectId);
    
    if (!project) {
      return res.status(404).json({ error: "Project not found" });
    }
    
    // Only admins or the project owner can update the project
    if (!req.user || (req.user.role !== "admin" && req.user.id !== project.userId)) {
      return res.status(403).json({ error: "Unauthorized" });
    }
    
    try {
      const projectData = insertProjectSchema.partial().parse(req.body);
      const updatedProject = await storage.updateProject(projectId, projectData);
      res.json(updatedProject);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update project" });
    }
  });

  app.delete("/api/projects/:id", isAuthenticated, async (req, res) => {
    const projectId = parseInt(req.params.id);
    const project = await storage.getProject(projectId);
    
    if (!project) {
      return res.status(404).json({ error: "Project not found" });
    }
    
    // Only admins or the project owner can delete the project
    if (!req.user || (req.user.role !== "admin" && req.user.id !== project.userId)) {
      return res.status(403).json({ error: "Unauthorized" });
    }
    
    await storage.deleteProject(projectId);
    res.status(204).send();
  });

  // AI Assistant routes
  app.post("/api/ai/marketing-assistant", isAuthenticated, async (req, res) => {
    try {
      const { prompt, domain, task, context } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }
      
      const response = await getAIMarketingResponse(prompt, domain, task, context);
      res.json({ response });
    } catch (error) {
      console.error("AI Assistant error:", error);
      res.status(500).json({ error: "Failed to process AI request" });
    }
  });

  app.post("/api/ai/content-ideas", isAuthenticated, async (req, res) => {
    try {
      const { topic, count, domain } = req.body;
      if (!topic) {
        return res.status(400).json({ error: "Topic is required" });
      }
      
      const ideas = await generateContentIdeas(topic, count || 5, domain);
      res.json({ ideas });
    } catch (error) {
      console.error("Content ideas error:", error);
      res.status(500).json({ error: "Failed to generate content ideas" });
    }
  });

  app.post("/api/ai/seo-analysis", isAuthenticated, async (req, res) => {
    try {
      const { url, industry } = req.body;
      if (!url) {
        return res.status(400).json({ error: "URL is required" });
      }
      
      const analysis = await analyzeSEO(url, industry);
      res.json(analysis);
    } catch (error) {
      console.error("SEO analysis error:", error);
      res.status(500).json({ error: "Failed to analyze SEO" });
    }
  });

  app.post("/api/ai/marketing-copy", isAuthenticated, async (req, res) => {
    try {
      const { product, platform, tone, targetAudience } = req.body;
      if (!product || !platform) {
        return res.status(400).json({ error: "Product and platform are required" });
      }
      
      const copy = await generateMarketingCopy(product, platform, tone, targetAudience);
      res.json({ copy });
    } catch (error) {
      console.error("Marketing copy error:", error);
      res.status(500).json({ error: "Failed to generate marketing copy" });
    }
  });
  
  app.post("/api/ai/business-document", isAuthenticated, async (req, res) => {
    try {
      const { documentType, details, industry } = req.body;
      if (!documentType || !details) {
        return res.status(400).json({ error: "Document type and details are required" });
      }
      
      const document = await generateBusinessDocument(documentType, details, industry);
      res.json({ document });
    } catch (error) {
      console.error("Business document generation error:", error);
      res.status(500).json({ error: "Failed to generate business document" });
    }
  });

  // Messages API for chat history
  app.get("/api/messages", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      const messages = await storage.getMessagesByUserId(req.user.id);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  app.post("/api/messages", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      // Override userId with authenticated user's ID
      // userId is required in the schema, but we'll set it here
      const { content, role } = req.body;
      
      if (!content || !role) {
        return res.status(400).json({ error: "Content and role are required" });
      }
      
      const message = await storage.createMessage({
        content,
        role,
        userId: req.user.id
      });
      
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error creating message:", error);
      res.status(500).json({ error: "Failed to create message" });
    }
  });

  app.delete("/api/messages", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      await storage.deleteAllMessagesByUserId(req.user.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting messages:", error);
      res.status(500).json({ error: "Failed to delete messages" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}

// Note: Middleware functions are now imported from auth.ts